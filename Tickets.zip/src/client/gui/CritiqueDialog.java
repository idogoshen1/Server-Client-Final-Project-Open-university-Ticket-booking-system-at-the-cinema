package client.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import client.Client;
import db.Critique;

/**
 * dialog for adding a new critique for a show
 * @author Ido Goshen
 *
 */
public class CritiqueDialog extends JDialog {
	/**
	 * the max rank
	 */
	static private final int RANK_NUMBER = 5;
	/**
	 * the buttons for selecting the rank
	 */
	private ArrayList<JButton> rankButtons = new ArrayList<JButton>();
	/**
	 * the critique text
	 */
	private JTextArea critiqueText;
	/**
	 * the new created critique
	 */
	private Critique critique;

	public CritiqueDialog() {
		setLayout(new BorderLayout());

		JPanel rankPanel = new JPanel();
		add(BorderLayout.NORTH, rankPanel);

		JLabel label = GeneralLookAndFeel.createLabel("Rank: ");
		GridBagConstraints gbc = GeneralLookAndFeel.createGridBagConstraints();
		JPanel rankButtonsPanel = new JPanel();
		rankButtonsPanel.setLayout(new GridLayout(1, RANK_NUMBER));
		// add the buttons for the rank
		for (int i = 0; i < RANK_NUMBER; i++) {
			JButton button = new JButton(String.valueOf(i + 1));
			rankButtonsPanel.add(button);
			rankButtons.add(button);
			button.setSelected(true);
			button.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					boolean found = false;
					// set the 1 - current buttons ass selected and the
					// rest as not selected
					for (JButton b : rankButtons) {
						b.setSelected(!found);
						if (b == e.getSource()) {
							found = true;
						}
					}
				}
			});
		}

		GeneralLookAndFeel.addComponents(label, rankButtonsPanel, rankPanel, gbc);
		JPanel critiquePanel = new JPanel();
		add(BorderLayout.CENTER, critiquePanel);

		label = GeneralLookAndFeel.createLabel("Critique: ");
		Dimension dim = GeneralLookAndFeel.getTextFieldSize();
		critiqueText = new JTextArea();
		critiqueText.setPreferredSize(new Dimension((int)dim.getWidth(), (int)dim.getHeight() * 3));
		GeneralLookAndFeel.addComponents(label, critiqueText, critiquePanel, gbc);

		JPanel downPanel = new JPanel();
		add(BorderLayout.SOUTH, downPanel);
		JButton okButton = new JButton("OK");
		okButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				update();
				setVisible(false);
			}
		});
		JButton cancelButton = new JButton("Cancel");
		GeneralLookAndFeel.addComponents(okButton, cancelButton, downPanel, gbc);
		cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		pack();
	}

	/**
	 * update the critique for creation
	 */
	private void update() {
		critique = new Critique();
		// set the rank acording to the last selected button
		for (int i = 0; i < rankButtons.size(); i++) {
			JButton button = rankButtons.get(i);
			if (button.isSelected()) {
				critique.setCritiqueRank(i + 1);
			}
			else {
				break;
			}
		}
		critique.setShow(null); // this will be set in the panel
		critique.setCritiqueText(critiqueText.getText());
		critique.setUser(Client.getUser());
	}

	/**
	 * @return the critique
	 */
	public Critique getCritique() {
		return critique;
	}
}
