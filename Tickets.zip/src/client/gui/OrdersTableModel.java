package client.gui;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;

import client.Client;
import db.TicketsOrder;

/**
 * table model for the orders panel
 * @author Ido Goshen
 *
 */
public class OrdersTableModel extends ClearableTableModel implements TableModel {
	/**
	 * the list of existing orders
	 */
	private List<TicketsOrder> orders = new ArrayList<TicketsOrder>();

	OrdersTableModel() {
	}
	/**
	 * return the number of orders
	 */
	@Override
	public int privateGetRowCount() {
		if (orders == null)
			return 0;
		return orders.size();
	}

	/**
	 * return the number of columns
	 */
	@Override
	public int getColumnCount() {
		return 6;
	}

	/**
	 * return the name (title) of each column
	 */
	@Override
	public String getColumnName(int columnIndex) {
		switch(columnIndex) {
		case 0:
			return "ID";
		case 1:
			return "Screening";
		case 2:
			return "Paid";
		case 3:
			return "Order Date";
		case 4:
			return "Screening Date";
		case 5:
			return "Owner";
		}
		return null;
	}

	/**
	 * return the type of each column
	 */
	@Override
	public Class<?> getColumnClass(int columnIndex) {
		switch(columnIndex) {
		case 0:
			return Integer.class;
		case 1:
			return String.class;
		case 2:
			return Boolean.class;
		case 3:
			return Date.class;
		case 4:
			return String.class;
		case 5:
			return String.class;
		}
		return null;
	}

	/**
	 * prevent editing cells
	 */
	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}

	/**
	 * return the value in a specific cell
	 */
	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		switch(columnIndex) {
		case 0:
			return orders.get(rowIndex).getId();
		case 1:
			return orders.get(rowIndex).getScreening().getShow().getName();
		case 2:
			return orders.get(rowIndex).getPaid() == 1;
		case 3:
			return orders.get(rowIndex).getOrderDate();
		case 4:
			return GeneralLookAndFeel.getFormatted(orders.get(rowIndex).getScreening().getDateAndTime());
		case 5:
			return orders.get(rowIndex).getUser().getUserName();
		}
		return null;
	}

	@Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	@Override
	public void addTableModelListener(TableModelListener l) {
	}

	@Override
	public void removeTableModelListener(TableModelListener l) {
	}

	/**
	 * refresh the table content
	 */
	public void refresh() {
		orders = Client.getOrders(Client.getUser().getId());
	}
	/**
	 * get the order in a specific index
	 * @param row the index
	 * @return the order
	 */
	public TicketsOrder getSelected(int row) {
		return orders.get(row);
	}
}
