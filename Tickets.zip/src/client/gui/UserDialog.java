package client.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import client.BaseLoginWindow;
import db.User;

/**
 * dialog for adding a new user or editing an existing one
 * @author Ido Goshen
 *
 */
public class UserDialog extends BaseLoginWindow {
	/**
	 * the name field
	 */
	private JTextField userNameText;
	/**
	 * the first password field
	 */
	private JPasswordField passwordText1;
	/**
	 * the second password field
	 */
	private JPasswordField passwordText2;
	/**
	 * the first name field
	 */
	private JTextField firstName;
	/**
	 * the last name field
	 */
	private JTextField lastName;
	/**
	 * the mail field
	 */
	private JTextField mail;
	/**
	 * the phone field
	 */
	private JTextField phone;
	/**
	 * the manager check box
	 */
	private JCheckBox manager;
	/**
	 * true if the user details where changed
	 */
	private boolean changed = false;
	public UserDialog() {
		super(null);
		addContent();
	}
	public UserDialog(User user) {
		super(null);
		this.user = user;
		addContent();
	}
	/**
	 * add the content of the dialog
	 */
	private void addContent() {
		if (user == null) {
			setTitle("Sign Up");
		}
		else {
			setTitle("Edit User");
		}
		setLayout(new BorderLayout());

		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new GridBagLayout());
		add(centerPanel, BorderLayout.CENTER);
		GridBagConstraints gbc = GeneralLookAndFeel.createGridBagConstraints();

		JLabel label = GeneralLookAndFeel.createLabel("ID: ");
		Dimension dim = GeneralLookAndFeel.getTextFieldSize();
		JLabel IDlabel = GeneralLookAndFeel.createLabel("");
		if (user != null) {
			IDlabel.setText(String.valueOf(user.getId()));
		}
		IDlabel.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, IDlabel, centerPanel, gbc);

		label = GeneralLookAndFeel.createLabel("User name: ");
		userNameText = new JTextField();
		userNameText.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, userNameText, centerPanel, gbc);
		if (user != null) {
			userNameText.setText(user.getUserName());
		}

		label = GeneralLookAndFeel.createLabel("Password 1: ");
		passwordText1 = new JPasswordField();
		passwordText1.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, passwordText1, centerPanel, gbc);
		if (user != null) {
			passwordText1.setEnabled(false);
		}

		label = GeneralLookAndFeel.createLabel("Password 2: ");
		passwordText2 = new JPasswordField();
		passwordText2.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, passwordText2, centerPanel, gbc);
		if (user != null) {
			passwordText2.setEnabled(false);
		}

		label = GeneralLookAndFeel.createLabel("First Name: ");
		firstName = new JTextField();
		firstName.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, firstName, centerPanel, gbc);
		if (user != null) {
			firstName.setText(user.getFirstName());
		}

		label = GeneralLookAndFeel.createLabel("Last Name: ");
		lastName = new JTextField();
		lastName.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, lastName, centerPanel, gbc);
		if (user != null) {
			lastName.setText(user.getLastName());
		}

		label = GeneralLookAndFeel.createLabel("Mail: ");
		mail = new JTextField();
		mail.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, mail, centerPanel, gbc);
		if (user != null) {
			mail.setText(user.getMail());
		}

		label = GeneralLookAndFeel.createLabel("Phone: ");
		phone = new JTextField();
		phone.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, phone, centerPanel, gbc);
		if (user != null) {
			phone.setText(user.getPhone());
		}

		label = GeneralLookAndFeel.createLabel("Manager: ");
		manager = new JCheckBox();
		manager.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, manager, centerPanel, gbc);
		if (user != null) {
			manager.setSelected(user.getManager() == 1);
		}

		JButton updateButton = new JButton("Update");
		if (user == null) {
			updateButton = new JButton("Create");
		}
		updateButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				update();
			}
		});
		JButton cancelButton = new JButton("Cancel");
		GeneralLookAndFeel.addComponents(updateButton, cancelButton, centerPanel, gbc);
		cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		pack();
	}

	/**
	 * update or create the user
	 */
	private void update() {
		if (user == null) {
			// make sure that the 2 password copies match
			if (! String.valueOf(passwordText1.getPassword()).equals(String.valueOf(passwordText2.getPassword()))) {
				JOptionPane.showMessageDialog(null,
						"Password 1 and password 2 don't match", "Error",
						JOptionPane.ERROR_MESSAGE);
				return;
			}
			// make sure that the password is not empty
			if (String.valueOf(passwordText1.getPassword()).isEmpty()) {
				JOptionPane.showMessageDialog(null,
						"Password cannot be empty", "Error",
						JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
		// verify that all fields values are OK
		if (firstName.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null,
					"First name cannot be empty", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		if (lastName.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null,
					"Last name cannot be empty", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		if (mail.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null,
					"Mail cannot be empty", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		if (phone.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null,
					"Phone cannot be empty", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		boolean updated = true;
		if (user == null) {
			updated = false;
			user = new User();
		}
		changed = true;
		// update the user itself
		user.setUserName(userNameText.getText());
		if (! updated) {
			user.setPassword(String.valueOf(passwordText1.getPassword()));
		}
		user.setFirstName(firstName.getText());
		user.setLastName(lastName.getText());
		user.setMail(mail.getText());
		user.setPhone(phone.getText());
		user.setManager((byte) (manager.isSelected() ? 1 : 0));
		setVisible(false);
	}
	/**
	 * @return the changed
	 */
	public boolean userChanged() {
		return changed;
	}
	/**
	 * @return the user
	 */
	public User getUser() {
		return user;
	}
}
