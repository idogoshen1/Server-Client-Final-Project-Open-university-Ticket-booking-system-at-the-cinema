package client.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JDialog;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.table.TableModel;

import client.Client;
import db.Screening;
import db.Ticket;
import db.TicketsOrder;
import db.User;

/**
 * the panel for orders
 * @author Ido Goshen
 *
 */
public class OrdersPanel extends TablePanel<TicketsOrder> {
	public OrdersPanel() {
		/**
		 * add a pop up menu for paying an order
		 */
		JPopupMenu popupMenu = new JPopupMenu();
		JMenuItem payItem = new JMenuItem("Pay");
		popupMenu.add(payItem);
        table.setComponentPopupMenu(popupMenu);
		payItem.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int row = table.getSelectedRow();
				if (row >= 0) {
					// pay the order
					TicketsOrder to = ((OrdersTableModel)table.getModel()).getSelected(row);
					if (!Client.pay(to.getId())) {
						JOptionPane.showMessageDialog(null,
								"Cannot pay", "Error",
								JOptionPane.ERROR_MESSAGE);
					}
					else {
						refresh();
					}
				}
			}
		});
	}

	/**
	 * refresh the content of the panel
	 */
	public void refresh() {
		((ClearableTableModel)table.getModel()).unclear();
		((OrdersTableModel)table.getModel()).refresh();
		table.revalidate();
		revalidate();
	}

	/**
	 * return the extra data for edit
	 */
	@Override
	protected Object getExtraData() {
		return null;
	}

	/**
	 * return the selected order
	 */
	@Override
	protected TicketsOrder getSelected() {
		int selectedRow = table.getSelectedRow();
		if (selectedRow < 0) {
			JOptionPane.showMessageDialog(null,
					"No selected order", "Warning",
					JOptionPane.INFORMATION_MESSAGE);
			return null;
		}
		TicketsOrder order = ((OrdersTableModel)table.getModel()).getSelected(selectedRow);
		if (order == null) {
			JOptionPane.showMessageDialog(null,
					"No selected order", "Warning",
					JOptionPane.INFORMATION_MESSAGE);
			return null;
		}
		return order;
	}

	/**
	 * return new table model for the orders
	 */
	@Override
	protected TableModel getTableModel() {
		return new OrdersTableModel();
	}

	/**
	 * return the dialog for editing an order
	 */
	@Override
	protected JDialog getEditDialog(TicketsOrder t) {
		// Edit is not supported
		return null;
	}

	/**
	 * finish editing an order
	 */
	@Override
	protected boolean finishEdit(JDialog dialog, TicketsOrder obj) {
		// Edit is not supported
		return false;
	}

	/**
	 * handle delete of an order using the server
	 */
	@Override
	protected boolean handleDelete(TicketsOrder order) {
		if (Client.delete(order)) {
			JOptionPane.showMessageDialog(null,
					"Order deleted", "Info",
					JOptionPane.INFORMATION_MESSAGE);
			return true;
		}
		else {
			JOptionPane.showMessageDialog(null,
					"Cannot delete order", "Error",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	/**
	 * return the dialog for adding a new order
	 */
	@Override
	protected JDialog getAddDialog(Object extraData) {
		return new OrderDialog();
	}

	/**
	 * finish adding a new order
	 */
	@Override
	protected boolean finishAdd(JDialog dialog) {
		OrderDialog orderDialog = (OrderDialog) dialog;
		User user = Client.getUser();
		ArrayList<Ticket> tickets = orderDialog.getTickets();
		if ((tickets != null) && !tickets.isEmpty()) {
			Screening screening = orderDialog.getSelectedScreening();
			if (!Client.placeOrder(screening.getId(), user.getId(), tickets)) {
				JOptionPane.showMessageDialog(null,
						"Cannot create order", "Error",
						JOptionPane.ERROR_MESSAGE);
				return false;
			}
		}
		return true;
	}

	/**
	 * return false as edit is not supported
	 */
	protected boolean shouldHaveEditButton() {
		return false;
	}

	/**
	 * return true as any user can add a new order
	 */
	@Override
	protected boolean userCanAdd(User user) {
		return true;
	}

	/**
	 * return false as editing an order is not supported
	 */
	@Override
	protected boolean userCanEdit(User user) {
		return false;
	}

	/**
	 * return true as any user can delete an order
	 */
	@Override
	protected boolean userCanDelete(User user) {
		return true;
	}
}
