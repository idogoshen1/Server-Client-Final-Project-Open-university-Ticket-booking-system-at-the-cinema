package client.gui;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;

import client.Client;
import db.Show;
import db.User;

/**
 * the panel for showings the shows
 * @author Ido Goshen
 *
 */
public class ShowsPanel extends TablePanel<Show> {
	public ShowsPanel() {
	}

	/**
	 * return the selected show
	 */
	@Override
	protected Show getSelected() {
		int selectedRow = table.getSelectedRow();
		if (selectedRow < 0) {
			JOptionPane.showMessageDialog(null,
					"No selected show", "Warning",
					JOptionPane.INFORMATION_MESSAGE);
			return null;
		}
		Show show = ((ShowsTableModel)table.getModel()).getShow(selectedRow);
		if (show == null) {
			JOptionPane.showMessageDialog(null,
					"No selected user", "Warning",
					JOptionPane.INFORMATION_MESSAGE);
			return null;
		}
		return show;
	}

	/**
	 * return a new table model
	 */
	@Override
	protected TableModel getTableModel() {
		return new ShowsTableModel();
	}

	/**
	 * refresh the content of the panel
	 */
	@Override
	public void refresh() {
		((ClearableTableModel)table.getModel()).unclear();
		((ShowsTableModel)table.getModel()).refresh();
		table.revalidate();
		revalidate();
	}

	/**
	 * return the dialog for editing a show
	 */
	@Override
	protected JDialog getEditDialog(Show show) {
		return new ShowDialog(show);
	}

	/**
	 * finish editing a show
	 */
	@Override
	protected boolean finishEdit(JDialog dialog, Show show) {
		ShowDialog showDialog = (ShowDialog) dialog;
		if (showDialog.showChanged()) {
			if (! Client.update(show)) {
				JOptionPane.showMessageDialog(null,
						"Cannot update show", "Error",
						JOptionPane.ERROR_MESSAGE);
				return false;
			}
			return true;
		}
		return false;
	}

	/**
	 * handle delete of a show using the server
	 */
	@Override
	protected boolean handleDelete(Show show) {
		if (Client.delete(show)) {
			JOptionPane.showMessageDialog(null,
					"Show deleted", "Info",
					JOptionPane.INFORMATION_MESSAGE);
			return true;
		}
		else {
			JOptionPane.showMessageDialog(null,
					"Cannot delete show", "Error",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	/**
	 * return the dialog for adding a new show
	 */
	@Override
	protected JDialog getAddDialog(Object extraData) {
		return new ShowDialog();
	}

	/**
	 * finish adding a new show
	 */
	@Override
	protected boolean finishAdd(JDialog dialog) {
		ShowDialog showDialog = (ShowDialog) dialog;
		Show show = showDialog.getShow();
		if (show != null) {
			if (! Client.create(show)) {
				JOptionPane.showMessageDialog(null,
						"Cannot create show", "Error",
						JOptionPane.ERROR_MESSAGE);
				return false;
			}
			return true;
		}
		return true;
	}

	/**
	 * return extra data
	 */
	@Override
	protected Object getExtraData() {
		return null;
	}

	/**
	 * only a manager can add a new show
	 */
	@Override
	protected boolean userCanAdd(User user) {
		return user.getManager() == 1;
	}

	/**
	 * only a manager can edit a show
	 */
	@Override
	protected boolean userCanEdit(User user) {
		return user.getManager() == 1;
	}

	/**
	 * only a manager can delete a show
	 */
	@Override
	protected boolean userCanDelete(User user) {
		return user.getManager() == 1;
	}
}
