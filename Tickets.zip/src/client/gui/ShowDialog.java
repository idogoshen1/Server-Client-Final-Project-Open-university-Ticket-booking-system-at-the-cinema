package client.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import db.Show;

/**
 * a dialog for adding a new show or editing an existing one
 * @author Ido Goshen
 *
 */
public class ShowDialog extends JDialog {
	/**
	 * the show
	 */
	private Show show;
	/**
	 * the name field
	 */
	private JTextField nameText;
	/**
	 * the description field
	 */
	private JTextArea description;
	/**
	 * the image of the show
	 */
	private ImageIcon imageIcon;
	/**
	 * the label that holds the image
	 */
	private JLabel imageLabel;
	/**
	 * true if the image was changed
	 */
	private boolean imageChanged = false;
	/**
	 * true if the show was changed
	 */
	private boolean changed = false;

	public ShowDialog() {
		addContent();
	}
	public ShowDialog(Show show) {
		this.show = show;
		addContent();
	}
	/**
	 * add the content of the dialog
	 */
	private void addContent() {
		setTitle("Show");
		setLayout(new BorderLayout());

		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new GridBagLayout());
		add(centerPanel, BorderLayout.CENTER);
		GridBagConstraints gbc = GeneralLookAndFeel.createGridBagConstraints();

		JLabel label = GeneralLookAndFeel.createLabel("ID: ");
		Dimension dim = GeneralLookAndFeel.getTextFieldSize();
		JLabel IDlabel = GeneralLookAndFeel.createLabel("");
		if (show != null) {
			IDlabel.setText(String.valueOf(show.getId()));
		}
		IDlabel.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, IDlabel, centerPanel, gbc);

		label = GeneralLookAndFeel.createLabel("Name: ");
		nameText = new JTextField();
		nameText.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, nameText, centerPanel, gbc);
		if (show != null) {
			nameText.setText(show.getName());
		}

		label = GeneralLookAndFeel.createLabel("Description: ");
		description = new JTextArea();
		description.setPreferredSize(new Dimension((int)dim.getWidth(), (int)dim.getHeight() * 3));
		GeneralLookAndFeel.addComponents(label, description, centerPanel, gbc);
		if (show != null) {
			description.setText(show.getDescription());
		}

		label = GeneralLookAndFeel.createLabel("Image: ");
		imageIcon = new ImageIcon();
		imageLabel = new JLabel(imageIcon);
		imageLabel.setOpaque(true);
		imageLabel.setBackground(Color.RED);
		imageLabel.setPreferredSize(new Dimension((int)dim.getWidth(), (int)dim.getHeight() * 3));
		GeneralLookAndFeel.addComponents(label, imageLabel, centerPanel, gbc);
		if (show != null) {
			imageIcon = new ImageIcon(show.getImage());
			imageLabel.setIcon(imageIcon);
			fixImageSize();
		}
		/**
		 * add listener for clicking in the image
		 */
		imageLabel.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				// choose an image once the user clicks in the image
				JFileChooser fc = new JFileChooser();
				fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
				int returnVal = fc.showOpenDialog(getParent());
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					File file = fc.getSelectedFile();
					try {
						BufferedImage image = ImageIO.read(file);
						imageIcon.setImage(image);
						imageChanged = true;
						fixImageSize();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
			}
		});

		JButton updateButton = new JButton("Update");
		if (show == null) {
			updateButton = new JButton("Create");
		}
		updateButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				update();
			}
		});
		JButton cancelButton = new JButton("Cancel");
		GeneralLookAndFeel.addComponents(updateButton, cancelButton, centerPanel, gbc);
		cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		pack();
	}
	/**
	 * fix the size of the image to fit the display
	 */
	private void fixImageSize() {
		Image img = imageIcon.getImage();
		Dimension dim = imageLabel.getPreferredSize();
		Image newimg = img.getScaledInstance((int)dim.getWidth(), (int)dim.getHeight(), java.awt.Image.SCALE_SMOOTH);
		imageIcon = new ImageIcon( newimg );
		imageLabel.setIcon(imageIcon);
	}
	/**
	 * update the show or create a new one
	 */
	private void update() {
		if (nameText.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null,
					"Name cannot be empty", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		if (description.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null,
					"Description cannot be empty", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		boolean updated = true;
		if (show == null) {
			updated = false;
			show = new Show();
		}
		// update the show itself
		show.setDescription(description.getText());
		show.setName(nameText.getText());
		if (imageChanged)
		{
			try {
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				ImageIO.write((RenderedImage) imageIcon.getImage(), "jpg", baos );
				byte[] imageInByte=baos.toByteArray();
				show.setImage(imageInByte);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		changed = true;
		setVisible(false);
	}
	/**
	 * @return the show
	 */
	public Show getShow() {
		return show;
	}
	/**
	 * @return is the show was changed
	 */
	public boolean showChanged() {
		return changed;
	}
}
