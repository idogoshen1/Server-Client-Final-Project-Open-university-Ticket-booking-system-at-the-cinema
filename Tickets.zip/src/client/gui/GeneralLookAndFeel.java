package client.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Toolkit;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.Border;
import javax.swing.plaf.ColorUIResource;

/**
 * class for general definitions for the look and feel
 * @author Ido Goshen
 *
 */
public class GeneralLookAndFeel {

	// colors
	public static final Color BORDER_COLOR = Color.BLUE;
	public static final Color RADIO_BUTTONS_COLOR = Color.WHITE;
	public static final Color LOGOUT_BUTTON_FOREGROUND = Color.RED;
	public static final Color TABLE_PANEL_COLOR = Color.YELLOW;
	public static final Color TABLE_BACKGROUND_COLOR = new Color(173, 216, 230); // light blue
	public static final Color BUTTOM_PANEL_BACKGROUND = Color.MAGENTA;
	private static final ColorUIResource TEXT_FIELD_BACKGROUND = new ColorUIResource(255, 255, 255);
	private static final ColorUIResource LABEL_BACKGROUND = new ColorUIResource(173, 216, 230); // light blue
	public static final Color TABLE_HEADER_BACKGROUND = Color.WHITE;

	// sizes
	/** width of the main window */
	final static public int width = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width - 300;
	/** height of the main window */
	final static public int height = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height - 300;
	/**
	 * the preferred size for text fields
	 */
	private static Dimension TextFieldSize;

	public static void init() {
		try {
			// set the look and feel to be nice
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
            ex.printStackTrace();
        }
		// the screen resolution
		int screenRes = Toolkit.getDefaultToolkit().getScreenResolution();
		// the font size according to the screen resolution
	    int fontSize = (int)Math.round(12.0 * screenRes / 92.0);
	    setUIFont(new javax.swing.plaf.FontUIResource("Arial", Font.PLAIN, fontSize));
	    // set the background color for all text fields
	    UIManager.put("TextField.background", TEXT_FIELD_BACKGROUND);
	    // set the background color for all labels
	    UIManager.put("Label.background", LABEL_BACKGROUND);
	    // set the background color for all text buttons
	    UIManager.put("Button.background", TEXT_FIELD_BACKGROUND);
	    JLabel label = new JLabel("User name: ");
		TextFieldSize = label.getPreferredSize();
		TextFieldSize = new Dimension(TextFieldSize.width * 2, TextFieldSize.height);
	}
	/**
	 * create a new label with the right background color
	 * @param text the text of the label
	 * @return
	 */
	public static JLabel createLabel(String text) {
		JLabel label = new JLabel(text);
		// enable background color
		label.setOpaque(true);
		return label;
	}
	/**
	 * set the default font for all UI elements
	 * @param font the font
	 */
	private static void setUIFont(javax.swing.plaf.FontUIResource font) {
		java.util.Enumeration keys = UIManager.getDefaults().keys();
		while (keys.hasMoreElements()) {
			Object key = keys.nextElement();
			Object value = UIManager.get(key);
			if (value instanceof javax.swing.plaf.FontUIResource)
				UIManager.put(key, font);
		}
	}
	/**
	 * @return the preferred size for text fields
	 */
	public static Dimension getTextFieldSize() {
		return TextFieldSize;
	}
	/**
	 * @return GridBagConstraints for all dialogs
	 */
	public static GridBagConstraints createGridBagConstraints() {
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(3, 3, 3, 3);
		return gbc;
	}
	/**
	 * add components to a panel
	 * @param firstComponent the first component
	 * @param secondComponent the second component
	 * @param panel the panel
	 * @param gbc the constraint
	 */
	public static void addComponents(JComponent firstComponent, JComponent secondComponent, JPanel panel, GridBagConstraints gbc) {
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridwidth = GridBagConstraints.RELATIVE;
		panel.add(firstComponent, gbc);
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		panel.add(secondComponent, gbc);
	}
	/**
	 * add a component to a panel
	 * @param component the component
	 * @param panel the panel
	 * @param gbc the constraint
	 */
	public static void addComponent(JComponent component, JPanel panel, GridBagConstraints gbc) {
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridwidth = GridBagConstraints.RELATIVE;
		panel.add(component, gbc);
	}
	/**
	 * @param date the date
	 * @return the date formatted as "dd MMMMM yyyy HH:mm" for display
	 */
	public static String getFormatted(Date date) {
		String pattern = "dd MMMMM yyyy HH:mm";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		return simpleDateFormat.format(date);
	}
	/**
	 * @return border when required
	 */
	public static Border getBorder() {
		return BorderFactory.createLineBorder(GeneralLookAndFeel.BORDER_COLOR, 2);
	}
}
