package client.gui;

/**
 * base class for table models that can be cleared so nothing is being showed
 * this is used for the case that the user does logout and we want to show nothing
 * on the current panel
 * @author Ido Goshen
 *
 */
public abstract class ClearableTableModel {
	/**
	 * true if the model is "cleared"
	 */
	private boolean cleared = false;

	/**
	 * clear the model
	 */
	public void clear() {
		cleared = true;
	}
	/**
	 * no rows if the model is "cleared"
	 * @return the number of rows
	 */
	public int getRowCount() {
		if (cleared) {
			return 0;
		}
		return privateGetRowCount();
	}
	/**
	 * show back the content of the model
	 */
	public void unclear() {
		cleared = false;
	}
	/**
	 * @return the actual number of rows
	 */
	protected abstract int privateGetRowCount();
}
