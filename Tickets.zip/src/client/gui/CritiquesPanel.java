package client.gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import client.Client;
import db.Critique;
import db.Show;

/**
 * class for the panel of the critiques of a show
 * @author Ido Goshen
 *
 */
public class CritiquesPanel extends JPanel {
	/**
	 * the list of shows
	 */
	private JComboBox<Show> shows = new JComboBox<Show>();
	/**
	 * the panel that shows the critiques
	 */
	private JPanel critiquesListPanel = new JPanel();
	/**
	 * the all text of the critiques
	 */
	private JTextArea allCritiquesText;

	public CritiquesPanel() {
		setLayout(new BorderLayout());
		add(BorderLayout.NORTH, shows);
		add(BorderLayout.CENTER, new JScrollPane(critiquesListPanel));
		critiquesListPanel.setLayout(new BoxLayout(critiquesListPanel, BoxLayout.Y_AXIS));
		allCritiquesText = new JTextArea();
		allCritiquesText.setEnabled(false);
		critiquesListPanel.add(allCritiquesText);

		JPanel buttomPanel = new JPanel();
		buttomPanel.setBackground(GeneralLookAndFeel.BUTTOM_PANEL_BACKGROUND);
		add(BorderLayout.SOUTH, buttomPanel);
		JButton addButton = new JButton("Add");
		addButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				addNewCritique();
			}
		});
		buttomPanel.add(addButton);
		shows.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					// update the critiques list
					updateCritiquesList();
				}
			}
		});
	}

	/**
	 * refresh the panel
	 */
	public void refresh() {
		shows.removeAllItems();
		List<Show> allShows = Client.getAllShows();
		for (Show show : allShows) {
			shows.addItem(show);
		}
		updateCritiquesList();
	}

	/**
	 * update the critiques according to the selected show
	 */
	private void updateCritiquesList() {
		Show show = (Show) shows.getSelectedItem();
		if (show == null)
			return;
		List<Critique> critiques = Client.getCritiques(show);
		if (critiques == null)
			return;
		// use StringBuffer for efficiency
		StringBuffer sb = new StringBuffer();
		int sumCritique = 0;
		// build the all text
		for (Critique critique : critiques) {
			sumCritique += critique.getCritiqueRank();
			sb.append("User: " + critique.getUser().getFirstName() + " " + critique.getUser().getLastName() + "\n");
			sb.append("Rank:" + String.valueOf(critique.getCritiqueRank()) + "\n");
			sb.append("Critique:" + critique.getCritiqueText() + "\n");
			sb.append("---------------------------------\n");
		}
		// add the average
		if (critiques.size() > 0) {
			sb.append("Average Rank: " + sumCritique / critiques.size());
		}
		allCritiquesText.setText(sb.toString());
		critiquesListPanel.revalidate();
	}
	/**
	 * add a new critique
	 */
	private void addNewCritique() {
		CritiqueDialog critiqueDialog = new CritiqueDialog();
		critiqueDialog.setModal(true);
		critiqueDialog.setVisible(true);
		Critique critique = critiqueDialog.getCritique();
		if (critique != null) {
			critique.setShow((Show)shows.getSelectedItem());
			if (! Client.create(critique)) {
				JOptionPane.showMessageDialog(null,
						"Cannot create critique", "Error",
						JOptionPane.ERROR_MESSAGE);
			}
			else {
				updateCritiquesList();
			}
		}
	}
}
