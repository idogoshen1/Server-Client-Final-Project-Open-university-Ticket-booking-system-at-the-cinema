package client.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

import client.Client;
import db.User;

/**
 * class for a dialog for changing the password
 * @author Ido Goshen
 *
 */
public class ChangePasswordDialog extends JDialog {
	/**
	 * first copy of the new password 
	 */
	private JPasswordField passwordText1 = new JPasswordField();
	/**
	 * second copy of the new password 
	 */
	private JPasswordField passwordText2 = new JPasswordField();
	private User user;

	public ChangePasswordDialog(User user) {
		this.user = user;
		addContent();
	}

	/**
	 * add the content of the dialog
	 */
	private void addContent() {
		setTitle("Change Password");
		setLayout(new BorderLayout());

		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new GridBagLayout());
		add(centerPanel, BorderLayout.CENTER);
		GridBagConstraints gbc = GeneralLookAndFeel.createGridBagConstraints();

		JLabel label = GeneralLookAndFeel.createLabel("Password 1: ");
		Dimension dim = GeneralLookAndFeel.getTextFieldSize();
		passwordText1 = new JPasswordField();
		passwordText1.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, passwordText1, centerPanel, gbc);

		label = GeneralLookAndFeel.createLabel("Password 2: ");
		passwordText2 = new JPasswordField();
		passwordText2.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, passwordText2, centerPanel, gbc);

		JButton updateButton = new JButton("Update");
		updateButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				update();
			}
		});
		JButton cancelButton = new JButton("Cancel");
		GeneralLookAndFeel.addComponents(updateButton, cancelButton, centerPanel, gbc);
		cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		pack();
	}
	/**
	 * make sure that everything is fine and update the password
	 */
	public void update() {
		// make sure that both copies of the new password are identical
		if (! String.valueOf(passwordText1.getPassword()).equals(String.valueOf(passwordText2.getPassword()))) {
			JOptionPane.showMessageDialog(null,
					"Password 1 and password 2 don't match", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		if (String.valueOf(passwordText1.getPassword()).isEmpty()) {
			JOptionPane.showMessageDialog(null,
					"Password cannot be empty", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		user.setPassword(String.valueOf(passwordText1.getPassword()));
		try {
			if (! Client.update(user)) {
				JOptionPane.showMessageDialog(null,
						"Cannot update password", "Error",
						JOptionPane.ERROR_MESSAGE);
			}
			else {
				setVisible(false);
			}
		} catch (Exception e) {
			String message = e.getMessage();
			if (e.getCause() != null) {
				message = e.getCause().getMessage();
			}
			JOptionPane.showMessageDialog(null,
					message, "Error",
					JOptionPane.ERROR_MESSAGE);
		}
	}
}
