package client.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import client.Client;
import db.City;
import db.Hall;
import db.Street;

/**
 * dialog for creating and editing an existing hall
 * @author Ido Goshen
 *
 */
public class HallDialog extends JDialog {
	/**
	 * the hall
	 */
	private Hall hall;
	/**
	 * the name of the hall
	 */
	private JTextField nameText;
	/**
	 * the list of cities
	 */
	private JComboBox<City> cities;
	/**
	 * the list o streets in the selected city
	 */
	private JComboBox<Street> streets;
	/**
	 * the house number
	 */
	private JTextField houseNumber;
	/**
	 * the number of lines in the hall
	 */
	private JTextField lines;
	/**
	 * the number of seats in each line
	 */
	private JTextField columns;
	/**
	 * the phone number
	 */
	private JTextField phone;
	/**
	 * true if the hall was changed in case of editing an existing hall
	 */
	private boolean changed = false;
	/**
	 * @param hall the hall
	 */
	public HallDialog(Hall hall) {
		this.hall = hall;
		addContent();
	}
	/**
	 * add the content of the dialog
	 */
	private void addContent() {
		setTitle("Hall");
		setLayout(new BorderLayout());

		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new GridBagLayout());
		add(centerPanel, BorderLayout.CENTER);
		GridBagConstraints gbc = GeneralLookAndFeel.createGridBagConstraints();

		JLabel label = GeneralLookAndFeel.createLabel("ID: ");
		Dimension dim = GeneralLookAndFeel.getTextFieldSize();
		JLabel IDlabel = GeneralLookAndFeel.createLabel("");
		if (hall != null) {
			IDlabel.setText(String.valueOf(hall.getId()));
		}
		GeneralLookAndFeel.addComponents(label, IDlabel, centerPanel, gbc);

		label = GeneralLookAndFeel.createLabel("Name: ");
		nameText = new JTextField();
		GeneralLookAndFeel.addComponents(label, nameText, centerPanel, gbc);
		nameText.setPreferredSize(dim);
		if (hall != null) {
			nameText.setText(hall.getName());
		}

		List<City> citiesList = Client.getAllCities();
		label = GeneralLookAndFeel.createLabel("City: ");
		cities = new JComboBox<City>();
		for (City c : citiesList) {
			cities.addItem(c);
		}
		GeneralLookAndFeel.addComponents(label, cities, centerPanel, gbc);
		if (hall != null) {
			cities.setSelectedItem(hall.getStreet().getCity());
		}
		cities.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				// when the selected city is changed, update the streets list
				// to be the streets in the selected city
				if (e.getStateChange() == ItemEvent.SELECTED) {
					City selectedCity = (City) e.getItem();
					fillStreetsAccordingToCity(selectedCity);
				}
			}

		});

		label = GeneralLookAndFeel.createLabel("Street: ");
		streets = new JComboBox<Street>();
		GeneralLookAndFeel.addComponents(label, streets, centerPanel, gbc);
		if (hall != null) {
			streets.setSelectedItem(hall.getStreet());
		}

		label = GeneralLookAndFeel.createLabel("House number: ");
		houseNumber = new JTextField();
		houseNumber.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, houseNumber, centerPanel, gbc);
		if (hall != null) {
			houseNumber.setText(String.valueOf(hall.getHouseNumber()));
		}

		label = GeneralLookAndFeel.createLabel("Lines: ");
		lines = new JTextField();
		lines.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, lines, centerPanel, gbc);
		if (hall != null) {
			lines.setText(String.valueOf(hall.getLines()));
		}

		label = GeneralLookAndFeel.createLabel("Columns: ");
		columns = new JTextField();
		columns.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, columns, centerPanel, gbc);
		if (hall != null) {
			columns.setText(String.valueOf(hall.getColumns()));
		}

		label = GeneralLookAndFeel.createLabel("Phone: ");
		phone = new JTextField();
		phone.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, phone, centerPanel, gbc);
		if (hall != null) {
			phone.setText(hall.getPhone());
		}

		JButton updateButton = new JButton("Update");
		if (hall == null) {
			updateButton = new JButton("Create");
		}
		updateButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				update();
			}
		});
		JButton cancelButton = new JButton("Cancel");
		GeneralLookAndFeel.addComponents(updateButton, cancelButton, centerPanel, gbc);
		cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		fillStreetsAccordingToCity((City)cities.getSelectedItem());
		pack();
	}

	/**
	 * check if the fields values are OK and update the hall accordingly
	 */
	private void update() {
		String name = nameText.getText().trim();
		if (name.isEmpty()) {
			JOptionPane.showMessageDialog(null,
					"Name cannot be empty", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		int houseNumberInt = 0;
		try {
			houseNumberInt = Integer.parseInt(houseNumber.getText().trim());
		}
		catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(null,
					"House number must be a number", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		int linesNumber = 0;
		try {
			linesNumber = Integer.parseInt(lines.getText().trim());
		}
		catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(null,
					"Lines number must be a number", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		int columnsNumber = 0;
		try {
			columnsNumber = Integer.parseInt(columns.getText().trim());
		}
		catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(null,
					"Columns number must be a number", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		String phoneStr = phone.getText().trim();
		if (phoneStr.isEmpty()) {
			JOptionPane.showMessageDialog(null,
					"Phone cannot be empty", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		if (hall == null)
			hall = new Hall();
		changed = true;
		hall.setName(name);
		hall.setStreet((Street) streets.getSelectedItem());
		hall.setColumns(columnsNumber);
		hall.setHouseNumber(houseNumberInt);
		hall.setLines(linesNumber);
		hall.setPhone(phoneStr);
		setVisible(false);
	}
	/**
	 * fill the streets list according to the selected city
	 * @param selectedCity the cty
	 */
	private void fillStreetsAccordingToCity(City selectedCity) {
		streets.removeAllItems();
		List<Street> selectedStreets = selectedCity.getStreets();
		for (Street s : selectedStreets) {
			streets.addItem(s);
		}
		streets.setSelectedIndex(0);
	}
	/**
	 * @return the hall
	 */
	public Hall getHall() {
		return hall;
	}
	/**
	 * @return true if the hall was changed
	 */
	public boolean hallChanged() {
		return changed;
	}
}
