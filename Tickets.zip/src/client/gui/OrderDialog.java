package client.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import client.Client;
import db.Hall;
import db.OrdersToTicket;
import db.Screening;
import db.Show;
import db.Ticket;
import db.TicketsOrder;

/**
 * the dialog for adding a new order
 * @author Ido Goshen
 *
 */
public class OrderDialog extends JDialog {
	/**
	 * the list of halls
	 */
	private JComboBox<Hall> halls = new JComboBox<Hall>();
	/**
	 * the list of shows
	 */
	private JComboBox<Show> shows = new JComboBox<Show>();
	/**
	 * the list of screenings of the show
	 */
	private JComboBox<Screening> screenings = new JComboBox<Screening>();
	/**
	 * the list of shows
	 */
	private List<Show> allShows;
	/**
	 * the list of check boxes of the seats
	 */
	private ArrayList<ArrayList<JCheckBox>> seats = new ArrayList<ArrayList<JCheckBox>>();
	/**
	 * the seats panel
	 */
	private JPanel seatsPanel = new JPanel();
	/**
	 * the list of tickets to be created according to the selected seats
	 */
	private ArrayList<Ticket> tickets = new ArrayList<Ticket>();

	public OrderDialog() {
		addContent();
	}
	/**
	 * add the content of the dialog
	 */
	private void addContent() {
		setTitle("Order");
		seatsPanel.setLayout(new GridLayout());
		setLayout(new BorderLayout());
		List<Hall> hallsList = Client.getAllHalls();
		for (Hall hall : hallsList) {
			halls.addItem(hall);
		}
		allShows = Client.getAllShows();
		for (Show show : allShows) {
			shows.addItem(show);
		}
		updateShowsAndScreenings();
		shows.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					updateShowsAndScreenings();
					revalidate();
				}
			}
		});
		halls.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					updateShowsAndScreenings();
					revalidate();
				}
			}
		});
		screenings.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					updateScreenings();
					revalidate();
				}
			}
		});

		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new GridBagLayout());
		add(centerPanel, BorderLayout.CENTER);
		GridBagConstraints gbc = GeneralLookAndFeel.createGridBagConstraints();

		JLabel label = GeneralLookAndFeel.createLabel("Hall: ");
		GeneralLookAndFeel.addComponents(label, halls, centerPanel, gbc);

		label = GeneralLookAndFeel.createLabel("Show: ");
		GeneralLookAndFeel.addComponents(label, shows, centerPanel, gbc);

		label = GeneralLookAndFeel.createLabel("Screening: ");
		GeneralLookAndFeel.addComponents(label, screenings, centerPanel, gbc);

		// set the size of seatsPanel
		seatsPanel.setPreferredSize(new Dimension(800, 300));
		// add fake label in the end of the line
		GeneralLookAndFeel.addComponents(seatsPanel, new JLabel(), centerPanel, gbc);

		JButton updateButton = new JButton("Create");
		updateButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				update();
			}
		});
		JButton cancelButton = new JButton("Cancel");
		GeneralLookAndFeel.addComponents(updateButton, cancelButton, centerPanel, gbc);
		cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		pack();
	}

	/**
	 * put in the screenings list the screenings that are in the selected hall
	 * and of the selected show
	 */
	private void updateShowsAndScreenings() {
		Hall hall = (Hall) halls.getSelectedItem();
		if (hall == null)
			return;
		Show show = (Show) shows.getSelectedItem();
		if (show == null)
			return;
		List<Screening> allScreenings = Client.getScreenings(show);
		if (allScreenings == null)
			return;
		screenings.removeAllItems();
		for (Screening screening : allScreenings) {
			if ((screening.getHall().getId() == hall.getId()) &&
					(screening.getShow().getId() == show.getId())) {
				screenings.addItem(screening);
			}
		}
		updateScreenings();
	}
	/**
	 * space around each combo box
	 */
	static private int COMBO_BOX_THRESHOLD = 7;
	/**
	 * set the display of the seats
	 */
	private void updateScreenings() {
		Hall hall = (Hall) halls.getSelectedItem();
		if (hall == null)
			return;
		Show show = (Show) shows.getSelectedItem();
		if (show == null)
			return;
		Screening screening = (Screening) screenings.getSelectedItem();
		if (screening == null)
			return;
		seatsPanel.removeAll();
		GridLayout layout = (GridLayout) seatsPanel.getLayout();
		layout.setRows(hall.getLines() + 1);
		layout.setColumns(hall.getColumns() + 1);
		JCheckBox cb;
		seats.clear();
		/**
		 * create labels for the rows and columns
		 */
		seatsPanel.add(new JLabel(), 0, 0);
		for (int j = 0; j < hall.getColumns(); j++) {
			seatsPanel.add(GeneralLookAndFeel.createLabel(String.valueOf(j + 1)), 0, j + 1);
		}
		for (int i = 0; i < hall.getLines(); i++) {
			ArrayList<JCheckBox> line = new ArrayList<JCheckBox>();
			seats.add(line);
			seatsPanel.add(GeneralLookAndFeel.createLabel(String.valueOf(i + 1) + ": "), i, 0);
			for (int j = 0; j < hall.getColumns(); j++) {
				cb = new JCheckBox();
				cb.setSize(new Dimension((int)cb.getPreferredSize().getWidth() + COMBO_BOX_THRESHOLD, (int)cb.getPreferredSize().getHeight() + COMBO_BOX_THRESHOLD));
				seatsPanel.add(cb, i + 1, j + 1);
				line.add(cb);
			}
		}
		// check the occupied seats and disable them
		List<TicketsOrder> orders = Client.getOrders(screening);
		Iterator<TicketsOrder> ticketsOrderIter = orders.iterator();
		while (ticketsOrderIter.hasNext()) {
			TicketsOrder to = ticketsOrderIter.next();
			List<OrdersToTicket> tickets = to.getOrdersToTickets();
			Iterator<OrdersToTicket> ticketsIter = tickets.iterator();
			while (ticketsIter.hasNext()) {
				OrdersToTicket otot = ticketsIter.next();
				Ticket ticket = otot.getTicket();
				cb = seats.get(ticket.getLine()).get(ticket.getColumn());
				cb.setSelected(true);
				cb.setEnabled(false);
			}
		}
		pack();
	}
	/**
	 * create the tickets list according to the user's selected seats
	 */
	private void update() {
		Screening screening = (Screening) screenings.getSelectedItem();
		if (screening == null) {
			JOptionPane.showMessageDialog(null,
					"No selected Screening", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		JCheckBox cb;
		Ticket ticket;
		tickets.clear();
		for (int i = 0; i < seats.size(); i++) {
			ArrayList<JCheckBox> seatsArray = seats.get(i);
			for (int j = 0; j < seatsArray.size(); j++) {
				cb = seatsArray.get(j);
				if (cb.isEnabled() && cb.isSelected()) {
					ticket = new Ticket();
					ticket.setColumn(j);
					ticket.setLine(i);
					tickets.add(ticket);
				}
			}
		}
		if (tickets.isEmpty()) {
			JOptionPane.showMessageDialog(null,
					"No seats selected", "Error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		setVisible(false);
	}
	/**
	 * @return the selected screening
	 */
	public Screening getSelectedScreening() {
		return (Screening) screenings.getSelectedItem();
	}
	/**
	 * @return the list of new tickets to be created
	 */
	public ArrayList<Ticket> getTickets() {
		return tickets;
	}
}
