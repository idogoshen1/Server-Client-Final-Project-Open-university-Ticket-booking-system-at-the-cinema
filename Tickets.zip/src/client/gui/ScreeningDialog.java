package client.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

import client.Client;
import db.Hall;
import db.Screening;
import db.Show;

/**
 * dialog for adding a new screening or editing an existing one
 * @author Ido Goshen
 *
 */
public class ScreeningDialog extends JDialog {
	/**
	 * the show of the screening
	 */
	private Show show;
	/**
	 * the screening
	 */
	private Screening screening;
	/**
	 * the list of shows
	 */
	private JComboBox<Show> shows = new JComboBox<Show>();
	/**
	 * the list of halls
	 */
	private JComboBox<Hall> halls = new JComboBox<Hall>();
	/**
	 * the list of times (00:00, 1:00 ...)
	 */
	private JComboBox<String> times = new JComboBox<String>();
	/**
	 * date picker for picking the date of the screening
	 */
	private JDatePickerImpl datePicker;
	/**
	 * true for the case that a screening is edited and was changed
	 */
	private boolean changed = false;

	public ScreeningDialog(Object extraData) {
		show = (Show) extraData;
		addContent();
	}
	public ScreeningDialog(Screening screening) {
		this.screening = screening;
		addContent();
	}
	/**
	 * add the content of the dialog
	 */
	private void addContent() {
		setTitle("Screening");
		setLayout(new BorderLayout());

		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new GridBagLayout());
		add(centerPanel, BorderLayout.CENTER);
		GridBagConstraints gbc = GeneralLookAndFeel.createGridBagConstraints();

		JLabel label = GeneralLookAndFeel.createLabel("ID: ");
		Dimension dim = GeneralLookAndFeel.getTextFieldSize();
		JLabel IDlabel = GeneralLookAndFeel.createLabel("");
		if (screening != null) {
			IDlabel.setText(String.valueOf(screening.getId()));
		}
		IDlabel.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, IDlabel, centerPanel, gbc);

		label = GeneralLookAndFeel.createLabel("Date and Time: ");
		Date today = new Date();
		UtilDateModel model = new UtilDateModel(today);
		model.setSelected(true);
		Properties props = new Properties();
		JDatePanelImpl datePanel = new JDatePanelImpl(model, props);
		datePicker = new JDatePickerImpl(datePanel, new DateLabelFormatter());
		for (int i = 0; i < 24; i++) {
			times.addItem(i + ":00");
		}
		JPanel tempPanel = new JPanel();
		tempPanel.add(datePicker);
		tempPanel.add(times);
		GeneralLookAndFeel.addComponents(label, tempPanel, centerPanel, gbc);
		if (screening != null) {
			model.setValue(screening.getDateAndTime());
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(screening.getDateAndTime());
			// for adding 12 for PM times
			int am = calendar.get(Calendar.AM_PM);
			String timeStr = String.format("%d:%02d", calendar.get(Calendar.HOUR) + 12 * am, calendar.get(Calendar.MINUTE));
			times.setSelectedItem(timeStr);
		}

		label = GeneralLookAndFeel.createLabel("Shows: ");
		// fill the shows
		List<Show> allShows = Client.getAllShows();
		for (Show show : allShows) {
			shows.addItem(show);
		}
		GeneralLookAndFeel.addComponents(label, shows, centerPanel, gbc);
		if (screening != null) {
			shows.setSelectedItem(screening.getShow());
		}
		else if (show != null) {
			shows.setSelectedItem(show);
		}

		label = GeneralLookAndFeel.createLabel("Halls: ");
		// fill the halls
		List<Hall> allHalls = Client.getAllHalls();
		for (Hall hall : allHalls) {
			halls.addItem(hall);
		}
		GeneralLookAndFeel.addComponents(label, halls, centerPanel, gbc);
		if (screening != null) {
			model.setValue(screening.getDateAndTime());
		}

		JButton updateButton = new JButton("Update");
		if (screening == null) {
			updateButton = new JButton("Create");
		}
		updateButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				update();
			}
		});
		JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		GeneralLookAndFeel.addComponents(updateButton, cancelButton, centerPanel, gbc);
		pack();
	}
	/**
	 * update or create the screening
	 */
	private void update() {
		if (screening == null) {
			screening = new Screening();
		}
		Date selectedDate = (Date) datePicker.getModel().getValue();
		String timeStr = (String) times.getSelectedItem();
		int index = timeStr.indexOf(':');
		int hours = Integer.parseInt(timeStr.substring(0, index));
		int minutes = Integer.parseInt(timeStr.substring(index + 1));
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(selectedDate);
		calendar.set( Calendar.AM_PM, Calendar.AM );
		calendar.set(Calendar.HOUR, hours);
		calendar.set(Calendar.MINUTE, minutes);
		selectedDate = calendar.getTime();

		screening.setDateAndTime(selectedDate);
		screening.setHall((Hall) halls.getSelectedItem());
		screening.setShow((Show) shows.getSelectedItem());
		changed = true;
		setVisible(false);
	}
	/**
	 * @return the screening
	 */
	public Screening getScreening() {
		return screening;
	}
	/**
	 * @return if the screening was changed
	 */
	public boolean screeningChanged() {
		return changed;
	}
}
