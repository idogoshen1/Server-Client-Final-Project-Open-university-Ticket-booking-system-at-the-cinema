package client.gui;

import java.util.ArrayList;
import java.util.List;

import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;

import client.Client;
import db.Show;

/**
 * table model for the shows panel
 * @author Ido Goshen
 *
 */
public class ShowsTableModel extends ClearableTableModel implements TableModel {
	/**
	 * the list of existing shows
	 */
	private List<Show> shows = new ArrayList<Show>();
	Show getUser(int index) {
		return shows.get(index);
	}

	/**
	 * return the number of shows
	 */
	@Override
	public int privateGetRowCount() {
		if (shows == null)
			return 0;
		return shows.size();
	}

	/**
	 * return the number of columns
	 */
	@Override
	public int getColumnCount() {
		return 3;
	}

	/**
	 * return the name (title) of each column
	 */
	@Override
	public String getColumnName(int columnIndex) {
		switch(columnIndex) {
		case 0:
			return "ID";
		case 1:
			return "Name";
		case 2:
			return "Description";
		}
		return null;
	}

	/**
	 * return the type of each column
	 */
	@Override
	public Class<?> getColumnClass(int columnIndex) {
		switch(columnIndex) {
		case 0:
			return Integer.class;
		case 1:
			return String.class;
		case 2:
			return String.class;
		}
		return null;
	}

	/**
	 * prevent editing cells
	 */
	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}
	/**
	 * get the show in a specific index
	 * @param index the index
	 * @return the show
	 */
	Show getShow(int index) {
		return shows.get(index);
	}

	/**
	 * return the value in a specific cell
	 */
	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		switch(columnIndex) {
		case 0:
			return shows.get(rowIndex).getId();
		case 1:
			return shows.get(rowIndex).getName();
		case 2:
			return shows.get(rowIndex).getDescription();
		}
		return null;
	}

	@Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	@Override
	public void addTableModelListener(TableModelListener l) {
	}

	@Override
	public void removeTableModelListener(TableModelListener l) {
	}

	/**
	 * refresh the table content
	 */
	public void refresh() {
		shows = Client.getAllShows();
	}
}
