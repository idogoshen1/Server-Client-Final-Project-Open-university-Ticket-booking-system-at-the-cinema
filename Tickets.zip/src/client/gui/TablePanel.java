package client.gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableModel;

import db.User;

/**
 * the generic panel that contains a table and edit, delete, add buttons
 * @author Ido Goshen
 *
 * @param <T> the parameter for the table (like User, Show...)
 */
public abstract class TablePanel<T> extends JPanel {
	/**
	 * the table
	 */
	protected JTable table = new JTable();
	/**
	 * the button for editing
	 */
	private JButton editButton;
	/**
	 * the button for deleting
	 */
	private JButton deleteButton;
	/**
	 * the button for adding
	 */
	private JButton addButton;

	protected TablePanel() {
		setLayout(new BorderLayout());
		// a table should be in a JScrollPane
		JScrollPane pane = new JScrollPane(table);
		pane.getViewport().setBackground(GeneralLookAndFeel.TABLE_PANEL_COLOR);
		add(BorderLayout.CENTER, pane);
		table.setModel(getTableModel());
		table.addMouseListener(new MouseAdapter() {
			@Override
	        public void mouseClicked(MouseEvent e) {
	            if (e.getClickCount() == 2) {
	                edit();
	            } else {
	            }
	        }
			});
		DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
		// set the alignment of the headers to be center
		renderer.setHorizontalAlignment(SwingConstants.CENTER);
		// set the background of the headers
		renderer.setBackground(GeneralLookAndFeel.TABLE_HEADER_BACKGROUND);
		for (int i = 0 ; i < table.getColumnCount(); i++){
			table.getColumnModel().getColumn(i).setHeaderRenderer(renderer);
		}
		table.setBackground(GeneralLookAndFeel.TABLE_BACKGROUND_COLOR);
		JPanel buttomPanel = new JPanel();
		buttomPanel.setBackground(GeneralLookAndFeel.BUTTOM_PANEL_BACKGROUND);
		add(BorderLayout.SOUTH, buttomPanel);
		addButton = new JButton("Add");
		addButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Object extraData = getExtraData();
				JDialog dialog = getAddDialog(extraData);
				dialog.setModal(true);
				dialog.setVisible(true);
				if (finishAdd(dialog)) {
					refresh();
				}
			}
		});
		buttomPanel.add(addButton);
		if (shouldHaveEditButton()) {
			editButton = new JButton("Edit");
			editButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					edit();
				}
			});
			buttomPanel.add(editButton);
		}
		deleteButton = new JButton("Delete");
		deleteButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				T obj = getSelected();
				if (obj == null)
					return;
				int option = JOptionPane.showConfirmDialog(null, "Are you sure?", "WARNING",
				        JOptionPane.YES_NO_OPTION);
				if (option == JOptionPane.YES_OPTION) {
					if (handleDelete(obj)) {
						refresh();
					}
				}
			}
		});
		buttomPanel.add(deleteButton);
	}
	/**
	 * @return true if this panel supports edit
	 */
	protected boolean shouldHaveEditButton() {
		return true;
	}
	/**
	 * edit an element
	 */
	private void edit() {
		T obj = getSelected();
		if (obj == null)
			return;
		JDialog dialog = getEditDialog(obj);
		if (dialog == null)
			return;
		dialog.setModal(true);
		dialog.setVisible(true);
		if (finishEdit(dialog, obj)) {
			refresh();
		}
	}
	/**
	 * clear the content of the table
	 */
	public void clear() {
		((ClearableTableModel)table.getModel()).clear();
		table.revalidate();
		revalidate();
	}
	/**
	 * update the visibility of the panel according to the ability of the user (manager or not)
	 * @param user the user
	 */
	public void updateAccordingToUser(User user) {
		if (addButton != null) {
			if (userCanAdd(user)) {
				addButton.setEnabled(true);
			}
			else {
				addButton.setEnabled(false);
			}
		}
		if (editButton != null) {
			if (userCanEdit(user)) {
				editButton.setEnabled(true);
			}
			else {
				editButton.setEnabled(false);
			}
		}
		if (deleteButton != null) {
			if (userCanDelete(user)) {
				deleteButton.setEnabled(true);
			}
			else {
				deleteButton.setEnabled(false);
			}
		}
	}
	/**
	 * @return extra data for adding a new element
	 */
	protected abstract Object getExtraData();
	/**
	 * @return the selected element
	 */
	abstract protected T getSelected();
	/**
	 * @return a new table model
	 */
	abstract protected TableModel getTableModel();
	/**
	 * refresh the content of the table
	 */
	abstract protected void refresh();
	/**
	 * return the dialog for editing an element
	 */
	abstract protected JDialog getEditDialog(T t);
	/**
	 * finish editing an element
	 */
	abstract protected boolean finishEdit(JDialog dialog, T obj);
	/**
	 * handle delete of an element using the server
	 */
	abstract protected boolean handleDelete(T obj);
	/**
	 * return the dialog for adding a new element
	 */
	abstract protected JDialog getAddDialog(Object extraData);
	/**
	 * finish adding a new element
	 */
	abstract protected boolean finishAdd(JDialog dialog);
	/**
	 * @param user the user
	 * @return true if this user can add a new element
	 */
	abstract protected boolean userCanAdd(User user);
	/**
	 * @param user the user
	 * @return true if this user can edit an element
	 */
	abstract protected boolean userCanEdit(User user);
	/**
	 * @param user the user
	 * @return true if this user can delete an element
	 */
	abstract protected boolean userCanDelete(User user);
}
