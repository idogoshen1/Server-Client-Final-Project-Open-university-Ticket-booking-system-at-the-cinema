package client.gui;

import java.util.ArrayList;
import java.util.List;

import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;

import client.Client;
import db.User;

/**
 * table model for the users panel
 * @author Ido Goshen
 *
 */
public class UsersTableModel extends ClearableTableModel implements TableModel {
	/**
	 * the list of existing users
	 */
	private List<User> users = new ArrayList<User>();
	/**
	 * get the user in a specific index
	 * @param index the index
	 * @return the user
	 */
	User getUser(int index) {
		return users.get(index);
	}

	/**
	 * return the number of users
	 */
	@Override
	public int privateGetRowCount() {
		if (users == null)
			return 0;
		return users.size();
	}

	/**
	 * return the number of columns
	 */
	@Override
	public int getColumnCount() {
		return 7;
	}

	/**
	 * return the name (title) of each column
	 */
	@Override
	public String getColumnName(int columnIndex) {
		switch(columnIndex) {
		case 0:
			return "ID";
		case 1:
			return "First Name";
		case 2:
			return "Last Name";
		case 3:
			return "User Name";
		case 4:
			return "Mail";
		case 5:
			return "Phone";
		case 6:
			return "Manager";
		}
		return null;
	}

	/**
	 * return the type of each column
	 */
	@Override
	public Class<?> getColumnClass(int columnIndex) {
		switch(columnIndex) {
		case 0:
			return Integer.class;
		case 1:
			return String.class;
		case 2:
			return String.class;
		case 3:
			return String.class;
		case 4:
			return String.class;
		case 5:
			return String.class;
		case 6:
			return Boolean.class;
		}
		return null;
	}

	/**
	 * prevent editing cells
	 */
	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}

	/**
	 * return the value in a specific cell
	 */
	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		switch(columnIndex) {
		case 0:
			return users.get(rowIndex).getId();
		case 1:
			return users.get(rowIndex).getFirstName();
		case 2:
			return users.get(rowIndex).getLastName();
		case 3:
			return users.get(rowIndex).getUserName();
		case 4:
			return users.get(rowIndex).getMail();
		case 5:
			return users.get(rowIndex).getPhone();
		case 6:
			return users.get(rowIndex).getManager() == 1 ? true : false;
		}
		return null;
	}

	@Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	@Override
	public void addTableModelListener(TableModelListener l) {
	}

	@Override
	public void removeTableModelListener(TableModelListener l) {
	}

	/**
	 * refresh the table content
	 */
	public void refresh() {
		users = Client.getAllUsers();
	}
}
