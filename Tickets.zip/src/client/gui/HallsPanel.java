package client.gui;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;

import client.Client;
import db.Hall;
import db.User;

/**
 * the panel for the halls
 * @author Ido Goshen
 *
 */
public class HallsPanel extends TablePanel<Hall> {

	public HallsPanel() {
	}

	/**
	 * refresh the panel content
	 */
	public void refresh() {
		((ClearableTableModel)table.getModel()).unclear();
		((HallsTableModel)table.getModel()).refresh();
		table.revalidate();
		revalidate();
	}

	/**
	 * return the selected hall
	 */
	@Override
	protected Hall getSelected() {
		int selectedRow = table.getSelectedRow();
		if (selectedRow < 0) {
			JOptionPane.showMessageDialog(null,
					"No selected user", "Warning",
					JOptionPane.INFORMATION_MESSAGE);
			return null;
		}
		Hall hall = ((HallsTableModel)table.getModel()).getHall(selectedRow);
		if (hall == null) {
			JOptionPane.showMessageDialog(null,
					"No selected hall", "Warning",
					JOptionPane.INFORMATION_MESSAGE);
			return null;
		}
		return hall;
	}

	/**
	 * return the table model
	 */
	@Override
	protected TableModel getTableModel() {
		return new HallsTableModel();
	}

	/**
	 * return the dialog for editing a hall
	 */
	@Override
	protected JDialog getEditDialog(Hall hall) {
		return new HallDialog(hall);
	}

	/**
	 * finish editing a hall
	 */
	@Override
	protected boolean finishEdit(JDialog dialog, Hall hall) {
		HallDialog hallDialog = (HallDialog) dialog;
		if (hallDialog.hallChanged()) {
			// update the hall using the server
			if (! Client.update(hall)) {
				JOptionPane.showMessageDialog(null,
						"Cannot update hall", "Error",
						JOptionPane.ERROR_MESSAGE);
				return false;
			}
			return true;
		}
		return false;
	}

	/**
	 * handle delete of a hall using the server
	 */
	@Override
	protected boolean handleDelete(Hall hall) {
		if (Client.delete(hall)) {
			JOptionPane.showMessageDialog(null,
					"Hall deleted", "Info",
					JOptionPane.INFORMATION_MESSAGE);
			return true;
		}
		else {
			JOptionPane.showMessageDialog(null,
					"Cannot delete hall", "Error",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	/**
	 * return the dialog for adding a new hall
	 */
	@Override
	protected JDialog getAddDialog(Object extraData) {
		return new HallDialog(null);
	}

	/**
	 * finish adding a new hall
	 */
	@Override
	protected boolean finishAdd(JDialog dialog) {
		HallDialog userDialog = (HallDialog) dialog;
		Hall hall = userDialog.getHall();
		if (hall != null) {
			if (! Client.create(hall)) {
				JOptionPane.showMessageDialog(null,
						"Cannot create hall", "Error",
						JOptionPane.ERROR_MESSAGE);
				return false;
			}
			return true;
		}
		return true;
	}

	/**
	 * return extra data for editing
	 */
	@Override
	protected Object getExtraData() {
		return null;
	}

	/**
	 * return true for manager that can add a new hall
	 */
	@Override
	protected boolean userCanAdd(User user) {
		return user.getManager() == 1;
	}

	/**
	 * return true for manager that can edit a hall
	 */
	@Override
	protected boolean userCanEdit(User user) {
		return user.getManager() == 1;
	}

	/**
	 * return true for manager that can delete a hall
	 */
	@Override
	protected boolean userCanDelete(User user) {
		return user.getManager() == 1;
	}
}
