package client.gui;

import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;

import client.Client;
import db.Screening;
import db.Show;

import java.util.ArrayList;
import java.util.List;

/**
 * table model for the screenings panel
 * @author Ido Goshen
 *
 */
public class ScreeningsTableModel extends ClearableTableModel implements TableModel {
	/**
	 * the list of existing screenings
	 */
	private List<Screening> screenings = new ArrayList<Screening>();

	/**
	 * refresh the table to show the screenings of a specific show
	 * @param show the show
	 */
	public void refresh(Show show) {
		screenings = Client.getScreenings(show);
	}

	/**
	 * return the number of screenings
	 */
	@Override
	public int privateGetRowCount() {
		if (screenings == null)
			return 0;
		return screenings.size();
	}

	/**
	 * return the number of columns
	 */
	@Override
	public int getColumnCount() {
		return 4;
	}

	/**
	 * return the name (title) of each column
	 */
	@Override
	public String getColumnName(int columnIndex) {
		switch(columnIndex) {
		case 0:
			return "ID";
		case 1:
			return "Date and Time";
		case 2:
			return "Hall";
		case 3:
			return "Show";
		}
		return null;
	}

	/**
	 * return the type of each column
	 */
	@Override
	public Class<?> getColumnClass(int columnIndex) {
		switch(columnIndex) {
		case 0:
			return Integer.class;
		case 1:
			return String.class;
		case 2:
			return String.class;
		case 3:
			return String.class;
		}
		return null;
	}

	/**
	 * prevent editing cells
	 */
	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}

	/**
	 * return the value in a specific cell
	 */
	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		switch(columnIndex) {
		case 0:
			return screenings.get(rowIndex).getId();
		case 1:
			return GeneralLookAndFeel.getFormatted(screenings.get(rowIndex).getDateAndTime());
		case 2:
			return screenings.get(rowIndex).getHall().getName();
		case 3:
			return screenings.get(rowIndex).getShow().getName();
		}
		return null;
	}

	@Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	@Override
	public void addTableModelListener(TableModelListener l) {
	}

	@Override
	public void removeTableModelListener(TableModelListener l) {
	}

	/**
	 * get the screening in a specific index
	 * @param selectedRow the index
	 * @return the screening
	 */
	public Screening getScreening(int selectedRow) {
		return screenings.get(selectedRow);
	}
}
