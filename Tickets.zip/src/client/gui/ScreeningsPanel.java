package client.gui;

import java.awt.BorderLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.List;

import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;

import client.Client;
import db.Screening;
import db.Show;
import db.User;

/**
 * panel for screenings according to selected show
 * @author Ido Goshen
 *
 */
public class ScreeningsPanel extends TablePanel<Screening> {
	/**
	 * the list of shows
	 */
	JComboBox<Show> shows = new JComboBox<Show>();
	public ScreeningsPanel() {
		add(BorderLayout.NORTH, shows);
		fillShows();
	}

	/**
	 * fill the list of shows
	 */
	private void fillShows() {
		shows.removeAllItems();
		List<Show> allShows = Client.getAllShows();
		if (allShows != null) {
			for (Show show : allShows) {
				shows.addItem(show);
			}
		}
		/**
		 * listen for selection of a show and update the table
		 * of screenings accordingly
		 */
		shows.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					// update the table
					((ScreeningsTableModel)table.getModel()).refresh((Show)e.getItem());
					table.revalidate();
					revalidate();
				}
			}
		});
	}
	/**
	 * refresh the content of the panel
	 */
	public void refresh() {
		((ClearableTableModel)table.getModel()).unclear();
		fillShows();
	}

	/**
	 * return the selected screening
	 */
	@Override
	protected Screening getSelected() {
		int selectedRow = table.getSelectedRow();
		if (selectedRow < 0) {
			JOptionPane.showMessageDialog(null,
					"No selected screening", "Warning",
					JOptionPane.INFORMATION_MESSAGE);
			return null;
		}
		Screening screening = ((ScreeningsTableModel)table.getModel()).getScreening(selectedRow);
		if (screening == null) {
			JOptionPane.showMessageDialog(null,
					"No selected screening", "Warning",
					JOptionPane.INFORMATION_MESSAGE);
			return null;
		}
		return screening;
	}

	/**
	 * return a new table model
	 */
	@Override
	protected TableModel getTableModel() {
		return new ScreeningsTableModel();
	}

	/**
	 * return the dialog for editing a screening
	 */
	@Override
	protected JDialog getEditDialog(Screening screening) {
		return new ScreeningDialog(screening);
	}

	/**
	 * finish editing a screening
	 */
	@Override
	protected boolean finishEdit(JDialog dialog, Screening screening) {
		ScreeningDialog screeningDialog = (ScreeningDialog) dialog;
		if (screeningDialog.screeningChanged()) {
			if (! Client.update(screening)) {
				JOptionPane.showMessageDialog(null,
						"Cannot update screening", "Error",
						JOptionPane.ERROR_MESSAGE);
				return false;
			}
			return true;
		}
		return false;
	}

	/**
	 * handle delete of a screening using the server
	 */
	@Override
	protected boolean handleDelete(Screening screening) {
		if (Client.delete(screening)) {
			JOptionPane.showMessageDialog(null,
					"Screening deleted", "Info",
					JOptionPane.INFORMATION_MESSAGE);
			return true;
		}
		else {
			JOptionPane.showMessageDialog(null,
					"Cannot delete screening", "Error",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	/**
	 * return the dialog for adding a new screening
	 */
	@Override
	protected JDialog getAddDialog(Object extraData) {
		return new ScreeningDialog(extraData);
	}

	/**
	 * return the dialog for adding a new screening
	 */
	@Override
	protected boolean finishAdd(JDialog dialog) {
		ScreeningDialog screeningDialog = (ScreeningDialog) dialog;
		Screening screening = screeningDialog.getScreening();
		if (screening != null) {
			if (! Client.create(screening)) {
				JOptionPane.showMessageDialog(null,
						"Cannot create screening", "Error",
						JOptionPane.ERROR_MESSAGE);
				return false;
			}
			return true;
		}
		return true;
	}

	/**
	 * return extra data
	 */
	@Override
	protected Object getExtraData() {
		return shows.getSelectedItem();
	}

	/**
	 * only a manager can add a new screening
	 */
	@Override
	protected boolean userCanAdd(User user) {
		return user.getManager() == 1;
	}

	/**
	 * only a manager can edit a screening
	 */
	@Override
	protected boolean userCanEdit(User user) {
		return user.getManager() == 1;
	}

	/**
	 * only a manager can delete a screening
	 */
	@Override
	protected boolean userCanDelete(User user) {
		return user.getManager() == 1;
	}
}
