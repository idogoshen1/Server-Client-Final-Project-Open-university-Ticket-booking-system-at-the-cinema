package client.gui;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;

import client.Client;
import db.User;

/**
 * panel for the users
 * @author Ido Goshen
 *
 */
public class UsersPanel extends TablePanel<User> {
	/**
	 * return a new table model
	 */
	protected TableModel getTableModel() {
		return new UsersTableModel();
	}
	/**
	 * return the dialog for editing a user
	 */
	protected JDialog getEditDialog(User user) {
		return new UserDialog(user);
	}
	/**
	 * return the dialog for adding a new user
	 */
	protected JDialog getAddDialog(Object extraData) {
		return new UserDialog();
	}
	/**
	 * handle delete of a user using the server
	 */
	protected boolean handleDelete(User user) {
		if (Client.delete(user)) {
			JOptionPane.showMessageDialog(null,
					"User deleted", "Info",
					JOptionPane.INFORMATION_MESSAGE);
			return true;
		}
		else {
			JOptionPane.showMessageDialog(null,
					"Cannot delete user", "Error",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}
	/**
	 * finish adding a new user
	 */
	protected boolean finishAdd(JDialog dialog) {
		UserDialog userDialog = (UserDialog) dialog;
		User user = userDialog.getUser();
		if (user != null) {
			try {
				if (! Client.create(user)) {
					JOptionPane.showMessageDialog(null,
							"Cannot create user", "Error",
							JOptionPane.ERROR_MESSAGE);
					return false;
				}
			} catch (Exception e) {
				String message = e.getMessage();
				if (e.getCause() != null) {
					message = e.getCause().getMessage();
				}
				JOptionPane.showMessageDialog(null,
						message, "Error",
						JOptionPane.ERROR_MESSAGE);
			}
			return true;
		}
		return true;
	}
	/**
	 * finish editing a user
	 */
	protected boolean finishEdit(JDialog dialog, User user) {
		UserDialog userDialog = (UserDialog) dialog;
		if (userDialog.userChanged()) {
			try {
				if (! Client.update(user)) {
					JOptionPane.showMessageDialog(null,
							"Cannot update user", "Error",
							JOptionPane.ERROR_MESSAGE);
					return false;
				}
			} catch (Exception e) {
				String message = e.getMessage();
				if (e.getCause() != null) {
					message = e.getCause().getMessage();
				}
				JOptionPane.showMessageDialog(null,
						message, "Error",
						JOptionPane.ERROR_MESSAGE);
			}
			return true;
		}
		return false;
	}

	public UsersPanel() {
	}

	/**
	 * return the selected user
	 */
	protected User getSelected() {
		int selectedRow = table.getSelectedRow();
		if (selectedRow < 0) {
			JOptionPane.showMessageDialog(null,
					"No selected user", "Warning",
					JOptionPane.INFORMATION_MESSAGE);
			return null;
		}
		User user = ((UsersTableModel)table.getModel()).getUser(selectedRow);
		if (user == null) {
			JOptionPane.showMessageDialog(null,
					"No selected user", "Warning",
					JOptionPane.INFORMATION_MESSAGE);
			return null;
		}
		return user;
	}
	/**
	 * refresh the content of the users table
	 */
	public void refresh() {
		((ClearableTableModel)table.getModel()).unclear();
		((UsersTableModel)table.getModel()).refresh();
		table.revalidate();
		revalidate();
	}
	/**
	 * the extra data
	 */
	@Override
	protected Object getExtraData() {
		return null;
	}

	/**
	 * only a manager can add a new user
	 */
	@Override
	protected boolean userCanAdd(User user) {
		return user.getManager() == 1;
	}

	/**
	 * only a manager can edit a user
	 */
	@Override
	protected boolean userCanEdit(User user) {
		return user.getManager() == 1;
	}

	/**
	 * only a manager can delete a user
	 */
	@Override
	protected boolean userCanDelete(User user) {
		return user.getManager() == 1;
	}
}
