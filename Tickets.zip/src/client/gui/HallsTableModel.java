package client.gui;

import java.util.ArrayList;
import java.util.List;

import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;

import client.Client;
import db.Hall;

/**
 * table model for the halls panel
 * @author Ido Goshen
 *
 */
public class HallsTableModel extends ClearableTableModel implements TableModel {
	/**
	 * the list of existing halls
	 */
	private List<Hall> halls = new ArrayList<Hall>();
	Hall getUser(int index) {
		return halls.get(index);
	}

	/**
	 * return the number of halls
	 */
	@Override
	public int privateGetRowCount() {
		if (halls == null)
			return 0;
		return halls.size();
	}

	/**
	 * return the number of columns
	 */
	@Override
	public int getColumnCount() {
		return 8;
	}

	/**
	 * return the name (title) of each column
	 */
	@Override
	public String getColumnName(int columnIndex) {
		switch(columnIndex) {
		case 0:
			return "ID";
		case 1:
			return "Name";
		case 2:
			return "City";
		case 3:
			return "Street";
		case 4:
			return "House Number";
		case 5:
			return "Lines";
		case 6:
			return "Columns";
		case 7:
			return "Phone";
		}
		return null;
	}

	/**
	 * return the type of each column
	 */
	@Override
	public Class<?> getColumnClass(int columnIndex) {
		switch(columnIndex) {
		case 0:
			return Integer.class;
		case 1:
			return String.class;
		case 2:
			return String.class;
		case 3:
			return String.class;
		case 4:
			return Integer.class;
		case 5:
			return Integer.class;
		case 6:
			return Integer.class;
		case 7:
			return String.class;
		}
		return null;
	}

	/**
	 * prevent editing cells
	 */
	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}
	/**
	 * get the hall in a specific index
	 * @param index the index
	 * @return the hall
	 */
	Hall getHall(int index) {
		return halls.get(index);
	}

	/**
	 * return the value in a specific cell
	 */
	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		switch(columnIndex) {
		case 0:
			return halls.get(rowIndex).getId();
		case 1:
			return halls.get(rowIndex).getName();
		case 2:
			return halls.get(rowIndex).getStreet().getCity().getName();
		case 3:
			return halls.get(rowIndex).getStreet().getName();
		case 4:
			return halls.get(rowIndex).getHouseNumber();
		case 5:
			return halls.get(rowIndex).getLines();
		case 6:
			return halls.get(rowIndex).getColumns();
		case 7:
			return halls.get(rowIndex).getPhone();
		}
		return null;
	}

	@Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	@Override
	public void addTableModelListener(TableModelListener l) {
	}

	@Override
	public void removeTableModelListener(TableModelListener l) {
	}

	/**
	 * refresh the table content
	 */
	public void refresh() {
		halls = Client.getAllHalls();
	}
}
