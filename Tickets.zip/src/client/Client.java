package client;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import client.gui.GeneralLookAndFeel;
import common.ServerManager;
import db.City;
import db.Critique;
import db.Hall;
import db.Screening;
import db.Show;
import db.Ticket;
import db.TicketsOrder;
import db.User;

/**
 * The main class in the client that manages all the client issues
 * and the connection to the server
 * @author Ido Goshen
 *
 */
public class Client {
	/**
	 * reference to the server
	 */
	static private ServerManager server;
	/**
	 * object for locking the server
	 */
	static private Object locker = new Object();
	/**
	 * reference to the currently logged user
	 */
	static private User user;
	/**
	 * the main window
	 */
	private static MainWindow win;
	/**
	 * the thread that is doing "ping" to the server to see if the server is alive
	 * and if it is not, try to reconnect
	 */
	private static Thread serverPingThread;
	/**
	 * make the login by asking the server to check if there is such user that has
	 * this password
	 * @param userName the user name
	 * @param password the password
	 * @return the user if it is exist
	 */
	static public User login(String userName, String password) {
		synchronized (locker) {
			try {
				if (server == null)
					return null;
				return server.getUser(userName, password);
			} catch (RemoteException e) {
				return null;
			}
		}
	}
	/**
	 * sign up a new user by asking the server to do it
	 * @param firstName the first name
	 * @param lastName the last name
	 * @param mail the mail
	 * @param userName the user name
	 * @param password the password
	 * @param phone the phone
	 * @return the new created user
	 * @throws Exception
	 */
	public static User signUp(String firstName, String lastName, String mail,
			String userName, String password, String phone) throws Exception {
		synchronized (locker) {
			if (server == null)
				return null;
			return server.signUp(firstName, lastName, mail,
					userName, password, phone);
		}
	}
	/**
	 * run the thread that pings the server...
	 */
	private static void initServerPingThread() {
		serverPingThread = new Thread() {

			@Override
			public void run() {
				super.run();
				while (true) {
					try {
						// sleep for half second
						Thread.sleep(500);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
					synchronized (locker) {
						if (server != null) {
							try {
								server.ping();
							} catch (RemoteException e) {
								server = null;
							}
						}
						if (server == null) {
							connectToServer();
						}
					}
					// update the main window
					win.setServerAlive(server != null);
				}
			}
		};
		serverPingThread.start();
	}
	/**
	 * connect to the server using RMI
	 */
	static private void connectToServer() {
		try {
			// connect to the server
			server = (ServerManager)Naming.lookup("//localhost/ServerManager");
			System.out.println("Client found ServerManager");
		} catch (MalformedURLException | RemoteException | NotBoundException e) {
			server = null;
		}
	}
	/**
	 * start the client
	 * @param args
	 */
	public static void main(String[] args) {
		GeneralLookAndFeel.init();
		initServerPingThread();
		// create the main window of the client
		win = new MainWindow();
		win.setVisible(true);
		win.start();
	}
	/**
	 * 
	 * @return the list of all users
	 */
	public static List<User> getAllUsers() {
		synchronized (locker) {
			try {
				if (server == null)
					return null;
				return server.getAllUsers();
			} catch (RemoteException e) {
				return null;
			}
		}
	}
	/**
	 * 
	 * @return the list of all halls
	 */
	public static List<Hall> getAllHalls() {
		synchronized (locker) {
			try {
				if (server == null)
					return null;
				return server.getAllHalls();
			} catch (RemoteException e) {
				return null;
			}
		}
	}
	/**
	 * delete a specific user from the DB
	 * @param user the user
	 * @return true on success
	 */
	public static boolean delete(User user) {
		synchronized (locker) {
			try {
				if (server == null)
					return false;
				return server.delete(user);
			} catch (RemoteException e) {
				return false;
			}
		}
	}
	/**
	 * update the user details
	 * @param user the user to be updated
	 * @return true on success
	 * @throws Exception
	 */
	public static boolean update(User user) throws Exception {
		synchronized (locker) {
			if (server == null)
				return false;
			return server.update(user);
		}
	}

	/**
	 * create a new user
	 * @param user the user to be created
	 * @return true on success
	 * @throws Exception
	 */
	public static boolean create(User user) throws Exception {
		synchronized (locker) {
			if (server == null)
				return false;
			return server.create(user);
		}
	}
	/**
	 * 
	 * @return the list of all cities
	 */
	public static List<City> getAllCities() {
		synchronized (locker) {
			try {
				if (server == null)
					return null;
				return server.getAllCities();
			} catch (RemoteException e) {
				return null;
			}
		}
	}
	/**
	 * create a new hall
	 * @param hall the hall to be created
	 * @return true on success
	 * @throws Exception
	 */
	public static boolean create(Hall hall) {
		synchronized (locker) {
			try {
				if (server == null)
					return false;
				return server.create(hall);
			} catch (RemoteException e) {
				return true;
			}
		}
	}
	/**
	 * delete a specific hall from the DB
	 * @param hall the hall
	 * @return true on success
	 */
	public static boolean delete(Hall hall) {
		synchronized (locker) {
			try {
				if (server == null)
					return false;
				return server.delete(hall);
			} catch (RemoteException e) {
				return false;
			}
		}
	}

	/**
	 * update the hall details
	 * @param hall the hall to be updated
	 * @return true on success
	 * @throws Exception
	 */
	public static boolean update(Hall hall) {
		synchronized (locker) {
			try {
				if (server == null)
					return false;
				return server.update(hall);
			} catch (RemoteException e) {
				return false;
			}
		}
	}
	/**
	 * 
	 * @return the list of all shows
	 */
	public static List<Show> getAllShows() {
		synchronized (locker) {
			try {
				if (server == null)
					return null;
				return server.getAllShows();
			} catch (RemoteException e) {
				return null;
			}
		}
	}
	/**
	 * create a new show
	 * @param show the show to be created
	 * @return true on success
	 * @throws Exception
	 */
	public static boolean create(Show show) {
		synchronized (locker) {
			try {
				if (server == null)
					return false;
				return server.create(show);
			} catch (RemoteException e) {
				return true;
			}
		}
	}
	/**
	 * update the show details
	 * @param show the show to be updated
	 * @return true on success
	 * @throws Exception
	 */
	public static boolean update(Show show) {
		synchronized (locker) {
			try {
				if (server == null)
					return false;
				return server.update(show);
			} catch (RemoteException e) {
				return false;
			}
		}
	}
	/**
	 * delete a specific show from the DB
	 * @param show the show
	 * @return true on success
	 */
	public static boolean delete(Show show) {
		synchronized (locker) {
			try {
				if (server == null)
					return false;
				return server.delete(show);
			} catch (RemoteException e) {
				return false;
			}
		}
	}
	/**
	 * 
	 * @param show the show
	 * @return the list of all screenings of a specific show
	 */
	public static List<Screening> getScreenings(Show show) {
		synchronized (locker) {
			try {
				if (server == null)
					return null;
				return server.getScreenings(show);
			} catch (RemoteException e) {
				return null;
			}
		}
	}
	/**
	 * create a new screening
	 * @param screening the screening to be created
	 * @return true on success
	 * @throws Exception
	 */
	public static boolean create(Screening screening) {
		synchronized (locker) {
			try {
				if (server == null)
					return false;
				return server.create(screening);
			} catch (RemoteException e) {
				return true;
			}
		}
	}
	/**
	 * delete a specific screening from the DB
	 * @param screening the screening
	 * @return true on success
	 */
	public static boolean delete(Screening screening) {
		synchronized (locker) {
			try {
				if (server == null)
					return false;
				return server.delete(screening);
			} catch (RemoteException e) {
				return false;
			}
		}
	}
	/**
	 * update the screening details
	 * @param screening the screening to be updated
	 * @return true on success
	 * @throws Exception
	 */
	public static boolean update(Screening screening) {
		synchronized (locker) {
			try {
				if (server == null)
					return false;
				return server.update(screening);
			} catch (RemoteException e) {
				return false;
			}
		}
	}
	public static User getUser() {
		return user;
	}
	public static void setUser(User user) {
		Client.user = user;
	}
	/**
	 * 
	 * @param screening the screening
	 * @return the list of all orders of a specific screening
	 */
	public static List<TicketsOrder> getOrders(Screening screening) {
		synchronized (locker) {
			try {
				if (server == null)
					return null;
				return server.getOrders(screening, user);
			} catch (RemoteException e) {
				return null;
			}
		}
	}
	public static boolean placeOrder(int screeningID, int userID, ArrayList<Ticket> tickets) {
		synchronized (locker) {
			try {
				if (server == null)
					return false;
				return server.placeOrder(screeningID, userID, tickets);
			} catch (RemoteException e) {
				return false;
			}
		}
	}
	/**
	 * 
	 * @param userID the ID of the user
	 * @return the list of all orders of a specific user
	 */
	public static List<TicketsOrder> getOrders(int userID) {
		synchronized (locker) {
			try {
				if (server == null)
					return null;
				return server.getOrders(userID);
			} catch (RemoteException e) {
				return null;
			}
		}
	}
	/**
	 * pay a specific order
	 * @param orderID tyhe ID of the order to pay
	 * @return true on success
	 */
	public static boolean pay(int orderID) {
		synchronized (locker) {
			try {
				if (server == null)
					return false;
				return server.pay(orderID);
			} catch (RemoteException e) {
				return false;
			}
		}
	}
	/**
	 * delete a specific order from the DB
	 * @param order the order
	 * @return true on success
	 */
	public static boolean delete(TicketsOrder order) {
		synchronized (locker) {
			try {
				if (server == null)
					return false;
				return server.delete(order);
			} catch (RemoteException e) {
				return false;
			}
		}
	}
	/**
	 * create a new critique
	 * @param critique the critique to be created
	 * @return true on success
	 * @throws Exception
	 */
	public static boolean create(Critique critique) {
		synchronized (locker) {
			try {
				if (server == null)
					return false;
				return server.create(critique);
			} catch (RemoteException e) {
				return false;
			}
		}
	}
	/**
	 * @param show the show
	 * @return the critiques of a specific show
	 */
	public static List<Critique> getCritiques(Show show) {
		synchronized (locker) {
			try {
				if (server == null)
					return null;
				return server.getCritiques(show);
			} catch (Exception e) {
				return null;
			}
		}
	}
}
