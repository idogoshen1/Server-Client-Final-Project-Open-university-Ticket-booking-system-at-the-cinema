package client;

import javax.swing.JDialog;

import db.User;

/**
 * Base class for login/sign up windows
 * @author Ido Goshen
 *
 */
public class BaseLoginWindow extends JDialog {
	/**
	 * the user
	 */
	protected User user;
    public BaseLoginWindow(JDialog owner) {
    	super(owner);
	}

	public User getUser() {
		return user;
	}

	protected void setUser(User user) {
		this.user = user;
	}

}
