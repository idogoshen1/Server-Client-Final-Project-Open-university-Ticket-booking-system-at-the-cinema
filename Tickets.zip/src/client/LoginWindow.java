package client;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import client.gui.GeneralLookAndFeel;

/**
 * Class for login
 * @author Ido Goshen
 *
 */
public class LoginWindow extends BaseLoginWindow {
	/**
	 * the user name
	 */
	private JTextField userNameText;
	/**
	 * the password
	 */
	private JPasswordField passwordText;

	public LoginWindow(JDialog owner) {
		super(owner);
		setTitle("Login");
		setLayout(new BorderLayout());
		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new GridBagLayout());
		add(centerPanel, BorderLayout.CENTER);
		GridBagConstraints gbc = GeneralLookAndFeel.createGridBagConstraints();

		JLabel label = GeneralLookAndFeel.createLabel("User name: ");
		Dimension dim = GeneralLookAndFeel.getTextFieldSize();
		userNameText = new JTextField();
		userNameText.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, userNameText, centerPanel, gbc);

		label = GeneralLookAndFeel.createLabel("Password: ");
		passwordText = new JPasswordField();
		passwordText.setPreferredSize(dim);
		GeneralLookAndFeel.addComponents(label, passwordText, centerPanel, gbc);

		JButton loginButton = new JButton("Login");
		loginButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				login();
			}
		});
		JButton exitButton = new JButton("Exit");
		GeneralLookAndFeel.addComponents(loginButton, exitButton, centerPanel, gbc);
		exitButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		// listen on the window for catching the event that the window
		// is being closed and exit the application in this case
		addWindowListener(new WindowListener() {
			@Override
			public void windowOpened(WindowEvent e) {
			}
			@Override
			public void windowIconified(WindowEvent e) {
			}
			@Override
			public void windowDeiconified(WindowEvent e) {
			}
			@Override
			public void windowDeactivated(WindowEvent e) {
			}
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0); // exit if the login window is being closed
			}
			@Override
			public void windowClosed(WindowEvent e) {
			}
			@Override
			public void windowActivated(WindowEvent e) {
			}
		});
		pack();
	}

	/**
	 * login the user
	 */
	private void login() {
		setUser(Client.login(userNameText.getText(), String.valueOf(passwordText.getPassword())));
		if (getUser() != null) {
			setVisible(false);
		}
		else {
			JOptionPane.showMessageDialog(null,
					"Bad user name of password", "Error",
					JOptionPane.ERROR_MESSAGE);
		}
	}
}
