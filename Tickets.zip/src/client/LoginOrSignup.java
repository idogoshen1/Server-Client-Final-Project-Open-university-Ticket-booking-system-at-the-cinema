package client;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

import client.gui.GeneralLookAndFeel;
import client.gui.UserDialog;
import db.User;

/**
 * Class for the dialog that asks the user to login or sign up
 * @author Ido Goshen
 *
 */
public class LoginOrSignup extends JDialog implements ActionListener {
	/**
	 * the user that was loged in or signed up
	 */
    private User user;
    // the buttons
	JButton loginButton;
	JButton signUpButton;
	JButton exitButton;
	public LoginOrSignup() {
		setTitle("Login/SignUp");
		setSize(500, 200);
		// set the grid and the gap between the buttons
		setLayout(new GridLayout(3, 1, 0, 3));
		loginButton = new JButton("Login");
		loginButton.setBorder(GeneralLookAndFeel.getBorder());
		add(loginButton);
		loginButton.addActionListener(this);
		signUpButton = new JButton("Sign Up");
		signUpButton.setBorder(GeneralLookAndFeel.getBorder());
		add(signUpButton);
		signUpButton.addActionListener(this);
		exitButton = new JButton("Exit");
		exitButton.setBorder(GeneralLookAndFeel.getBorder());
		add(exitButton);
		exitButton.addActionListener(this);
	}
	public User getUser() {
		return user;
	}

	/**
	 * method to be activated by the buttons
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == loginButton) {
			BaseLoginWindow win = new LoginWindow(this);
			win.setModal(true);
			win.setVisible(true);
			user = win.getUser();
		}
		else if (e.getSource() == signUpButton) {
			UserDialog userDialog = new UserDialog();
			userDialog.setModal(true);
			userDialog.setVisible(true);
			user = userDialog.getUser();
			if (user != null) {
				try {
					if (! Client.create(user)) {
						JOptionPane.showMessageDialog(null,
								"Cannot create user", "Error",
								JOptionPane.ERROR_MESSAGE);
					}
				} catch (Exception e1) {
					String message = e1.getMessage();
					if (e1.getCause() != null) {
						message = e1.getCause().getMessage();
					}
					JOptionPane.showMessageDialog(null,
							message, "Error",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		}
		else if (e.getSource() == exitButton) {
			System.exit(0);
		}
		if (user != null)
			setVisible(false);
	}

}
