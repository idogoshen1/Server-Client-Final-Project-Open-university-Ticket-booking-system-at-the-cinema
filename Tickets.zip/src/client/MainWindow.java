package client;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import client.gui.ChangePasswordDialog;
import client.gui.CritiquesPanel;
import client.gui.GeneralLookAndFeel;
import client.gui.HallsPanel;
import client.gui.OrdersPanel;
import client.gui.ScreeningsPanel;
import client.gui.ShowsPanel;
import client.gui.UserDialog;
import client.gui.UsersPanel;
import db.User;

/**
 * Class for the main window of the client
 * @author Ido Goshen
 *
 */
public class MainWindow extends JFrame {
	/**
	 * the width of the main window
	 */
	static final int MainWindowWidth = 1000;
	/**
	 * the height of the main window
	 */
	static final int MainWindowHeight = 600;
	/**
	 * the logged in user
	 */
	private User user;
	// the panels of the main window
	private UsersPanel usersPanel;
	private HallsPanel hallsPanel;
	private ShowsPanel showsPanel;
	private ScreeningsPanel screeningsPanel;
	private OrdersPanel ordersPanel;
	private CritiquesPanel critiquesPanel;
	/**
	 * the center panel that contains the card layout with the panels above
	 */
	private JPanel centerPanel;
	/**
	 * check box that shows that the server is alive and we are connected to it
	 */
	private JCheckBox serverAliveButton;
	// the radio buttons
	private JRadioButton showUsersButton;
	private JRadioButton changeUserDetailsButton;
	private JRadioButton showHallsButton;
	private JRadioButton showShowsButton;
	private JRadioButton showScreeningsButton;
	private JRadioButton manageOrdersButton;
	private JRadioButton changePasswordButton;
	private JRadioButton manageCritiquesButton;
	// empty panels
	private JPanel changeUserDetailsEmptyPanel;
	private JPanel changePasswordEmptyPanel;

	public MainWindow() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Tickets");
		setSize(MainWindowWidth, MainWindowHeight);
		setLayout(new BorderLayout());
		// add the left button with the radio buttons
		JPanel leftPanel = new JPanel();
		add(BorderLayout.WEST, leftPanel);
		// set the border of the left panel
		leftPanel.setBorder(GeneralLookAndFeel.getBorder());

		leftPanel.setLayout(new GridLayout(10, 1));
		// set the check box
		serverAliveButton = new JCheckBox("Server Alive");
		leftPanel.add(serverAliveButton);
		serverAliveButton.setEnabled(false);
		serverAliveButton.setBackground(Color.RED);
		serverAliveButton.setOpaque(true);
		serverAliveButton.setSelected(false);

		// set the radio buttons
		ButtonGroup rbGroup = new ButtonGroup();
		showUsersButton = new JRadioButton("Show Users");
		leftPanel.add(showUsersButton);
		rbGroup.add(showUsersButton);
		showUsersButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// switch to the "Users" panel
				CardLayout cardLayout = (CardLayout)(centerPanel.getLayout());
				cardLayout.show(centerPanel, "Users");
				usersPanel.refresh();
			}
		});
		changeUserDetailsButton = new JRadioButton("Change user details");
		leftPanel.add(changeUserDetailsButton);
		rbGroup.add(changeUserDetailsButton);
		changeUserDetailsButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// switch to the "Change user details" panel
				CardLayout cardLayout = (CardLayout)(centerPanel.getLayout());
				cardLayout.show(centerPanel, "ChangeUserDetailsEmptyPanel");
				UserDialog userDialog = new UserDialog(user);
				userDialog.setModal(true);
				userDialog.setVisible(true);
				if (userDialog.userChanged()) {
					try {
						if (! Client.update(user)) {
							JOptionPane.showMessageDialog(null,
									"Cannot update user", "Error",
									JOptionPane.ERROR_MESSAGE);
						}
					} catch (Exception ex) {
						JOptionPane.showMessageDialog(null,
								ex.getMessage(), "Error",
								JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		});
		showHallsButton = new JRadioButton("Show Halls");
		leftPanel.add(showHallsButton);
		rbGroup.add(showHallsButton);
		showHallsButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// switch to the "Show halls" panel
				CardLayout cardLayout = (CardLayout)(centerPanel.getLayout());
				cardLayout.show(centerPanel, "Halls");
				hallsPanel.refresh();
			}
		});
		showShowsButton = new JRadioButton("Show Shows");
		leftPanel.add(showShowsButton);
		rbGroup.add(showShowsButton);
		showShowsButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// switch to the "Show shows" panel
				CardLayout cardLayout = (CardLayout)(centerPanel.getLayout());
				cardLayout.show(centerPanel, "Shows");
				showsPanel.refresh();
			}
		});
		showScreeningsButton = new JRadioButton("Show Screenings");
		leftPanel.add(showScreeningsButton);
		rbGroup.add(showScreeningsButton);
		showScreeningsButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// switch to the "Show Screenings" panel
				CardLayout cardLayout = (CardLayout)(centerPanel.getLayout());
				cardLayout.show(centerPanel, "Screenings");
				screeningsPanel.refresh();
			}
		});
		manageOrdersButton = new JRadioButton("Manage Orders");
		leftPanel.add(manageOrdersButton);
		rbGroup.add(manageOrdersButton);
		manageOrdersButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// switch to the "Manage Orders" panel
				CardLayout cardLayout = (CardLayout)(centerPanel.getLayout());
				cardLayout.show(centerPanel, "Orders");
				ordersPanel.refresh();
			}
		});

		manageCritiquesButton = new JRadioButton("Manage Critiques");
		leftPanel.add(manageCritiquesButton);
		rbGroup.add(manageCritiquesButton);
		manageCritiquesButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// switch to the "Manage Orders" panel
				CardLayout cardLayout = (CardLayout)(centerPanel.getLayout());
				cardLayout.show(centerPanel, "Critiques");
				critiquesPanel.refresh();
			}
		});

		changePasswordButton = new JRadioButton("Change password");
		leftPanel.add(changePasswordButton);
		rbGroup.add(changePasswordButton);
		changePasswordButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// switch to the "Change password" panel
				CardLayout cardLayout = (CardLayout)(centerPanel.getLayout());
				cardLayout.show(centerPanel, "ChangePasswordEmptyPanel");
				ChangePasswordDialog changePasswordDialog = new ChangePasswordDialog(user);
				changePasswordDialog.setModal(true);
				changePasswordDialog.setVisible(true);
			}
		});
		// set the background color of the radio buttons
		Enumeration<AbstractButton> rbGroupElements = rbGroup.getElements();
		while (rbGroupElements.hasMoreElements()) {
			AbstractButton element = rbGroupElements.nextElement();
			element.setBackground(GeneralLookAndFeel.RADIO_BUTTONS_COLOR);
		}

		showUsersButton.setSelected(true);

		JButton button = new JButton("Logout");
		button.setForeground(GeneralLookAndFeel.LOGOUT_BUTTON_FOREGROUND);
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// do logout
				int option = JOptionPane.showConfirmDialog(null, "Are you sure?", "WARNING",
				        JOptionPane.YES_NO_OPTION);
				if (option == JOptionPane.YES_OPTION) {
					setUser(null);
					usersPanel.clear();
					hallsPanel.clear();
					showsPanel.clear();
					screeningsPanel.clear();
					ordersPanel.clear();
					start();
				}
			}
		});
		leftPanel.add(button);

		// initialize the center panel with CardLayout
		centerPanel = new JPanel(new CardLayout());
		add(BorderLayout.CENTER, centerPanel);
		centerPanel.setBorder(BorderFactory.createLineBorder(GeneralLookAndFeel.BORDER_COLOR, 2));
		usersPanel = new UsersPanel();
		centerPanel.add("Users", usersPanel);
		hallsPanel = new HallsPanel();
		centerPanel.add("Halls", hallsPanel);
		showsPanel = new ShowsPanel();
		centerPanel.add("Shows", showsPanel);
		screeningsPanel = new ScreeningsPanel();
		centerPanel.add("Screenings", screeningsPanel);
		ordersPanel = new OrdersPanel();
		centerPanel.add("Orders", ordersPanel);
		changeUserDetailsEmptyPanel = new JPanel();
		centerPanel.add("ChangeUserDetailsEmptyPanel", changeUserDetailsEmptyPanel);
		critiquesPanel = new CritiquesPanel();
		centerPanel.add("Critiques", critiquesPanel);
		changePasswordEmptyPanel = new JPanel();
		centerPanel.add("ChangePasswordEmptyPanel", changePasswordEmptyPanel);
	}
	/**
	 * set the checkbox state to show if the server is alive
	 * @param alive
	 */
	public void setServerAlive(boolean alive) {
		serverAliveButton.setSelected(alive);
		if (alive) {
			serverAliveButton.setBackground(Color.GREEN);
		}
		else {
			serverAliveButton.setBackground(Color.RED);
		}
	}
	/**
	 * do login
	 */
	public void start() {
		LoginOrSignup loginOrSignup = new LoginOrSignup();
		loginOrSignup.setModal(true);
		loginOrSignup.setVisible(true);
		user = loginOrSignup.getUser();
		setUser(user);
		if (user != null) {
			JOptionPane.showMessageDialog(null,
					"Wellcome " + user.getFirstName() + " " + user.getLastName(), "Wellcome",
					JOptionPane.INFORMATION_MESSAGE);
			usersPanel.refresh();
		}
		else {
			JOptionPane.showMessageDialog(null,
					"Exiting...", "Error",
					JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
	}
	/**
	 * set the user
	 * @param user the user
	 */
	public void setUser(User user) {
		this.user = user;
		Client.setUser(user);
		// update the window according to the existance of a user and if he is a manager
		if (user != null) {
			if (user.getManager() == 1) {
				showUsersButton.setEnabled(true);
				CardLayout cardLayout = (CardLayout)(centerPanel.getLayout());
				cardLayout.show(centerPanel, "Users");
				showUsersButton.setSelected(true);
			}
			else {
				showUsersButton.setEnabled(false);
				CardLayout cardLayout = (CardLayout)(centerPanel.getLayout());
				cardLayout.show(centerPanel, "Orders");
				manageOrdersButton.setSelected(true);
				ordersPanel.refresh();
			}
			usersPanel.updateAccordingToUser(user);
			hallsPanel.updateAccordingToUser(user);
			showsPanel.updateAccordingToUser(user);
			screeningsPanel.updateAccordingToUser(user);
			ordersPanel.updateAccordingToUser(user);
		}
	}
}
