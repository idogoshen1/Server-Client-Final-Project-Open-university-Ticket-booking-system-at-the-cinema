package utils;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

import org.w3c.dom.Element;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * class for reading cities and streets from a file and inserting them into the DB
 * @author Ido Goshen
 *
 */
public class CitiesAndStreetsReader {
	/**
	 * insert a city if it is not exiting yet in the DB
	 * @param connection the DB connection
	 * @param cityID the city ID
	 * @param cityName the city name
	 */
	static private void insertCityIfNotExist(Connection connection, int cityID, String cityName) {
		try {
			PreparedStatement statement = connection.prepareStatement("select * from cities where ID=" + cityID);
			ResultSet result = statement.executeQuery();
			if(result.next())
				return;
			String query = " insert into cities (ID, Name) values (?, ?)";
			PreparedStatement preparedStmt = connection.prepareStatement(query);
			preparedStmt.setInt(1, cityID);
			preparedStmt.setString (2, cityName);
			preparedStmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	/**
	 * insert a city if it is not exiting yet in the DB
	 * @param connection the DB connection
	 * @param streetID the street ID
	 * @param cityID the city ID
	 * @param streetName the street name
	 */
	static private void insertStreetIfNotExist(Connection connection, int streetID, int cityID, String streetName) {
		try {
			PreparedStatement statement = connection.prepareStatement("select * from streets where ID=" + streetID);
			ResultSet result = statement.executeQuery();
			if(result.next())
				return;
			String query = " insert into streets (ID, Name, CityID) values (?, ?, ?)";
			PreparedStatement preparedStmt = connection.prepareStatement(query);
			preparedStmt.setInt(1, streetID);
			preparedStmt.setString (2, streetName);
			preparedStmt.setInt(3, cityID);
			preparedStmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	/**
	 * read the cities and streets from XML file and fill the DB by them
	 */
	static private void fillCitiesAndStreetsByXML() {
		// from: https://mkyong.com/java/how-to-read-xml-file-in-java-dom-parser/
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			org.w3c.dom.Document doc = (org.w3c.dom.Document) db.parse(new File("cities_streets.xml"));
			// read only these cities in order not to fill the DB with too many data
			String cityNames [] = {"תל אביב - יפו", "ירושלים", "אשקלון","הרצליה", "נתניה", "פתח תקווה", "ראשון לציון"};
			Class driver = Class.forName("com.mysql.cj.jdbc.Driver");
			String connectionStr = "jdbc:mysql://localhost/Tickets?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
			Connection connection = DriverManager.getConnection(  
					connectionStr,"root","rootpassword");
			NodeList list = doc.getElementsByTagName("ROW");
			for (int temp = 0; temp < list.getLength(); temp++) {

				Node node = list.item(temp);

				if (node.getNodeType() == Node.ELEMENT_NODE) {

					Element element = (Element) node;

					String CityName = element.getElementsByTagName("שם_ישוב").item(0).getTextContent().trim();
					boolean contains = Arrays.stream(cityNames).anyMatch(CityName::equals);
					if (! contains)
						continue;
					String CityCode = element.getElementsByTagName("סמל_ישוב").item(0).getTextContent().trim();
					String StreetCode = element.getElementsByTagName("סמל_רחוב").item(0).getTextContent().trim();
					String StreetName = element.getElementsByTagName("שם_רחוב").item(0).getTextContent().trim();

					int cityID = Integer.parseInt(CityCode.trim());
					int streetID = Integer.parseInt(StreetCode.trim());
					insertCityIfNotExist(connection, cityID, CityName.trim());
					// make the street ID unique
					insertStreetIfNotExist(connection, 10000 * cityID + streetID, cityID, StreetName);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		fillCitiesAndStreetsByXML();
	}
}
