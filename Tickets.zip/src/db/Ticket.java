package db;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the tickets database table.
 * 
 */
@Entity
@Table(name="tickets")
@NamedQuery(name="Ticket.findAll", query="SELECT t FROM Ticket t")
public class Ticket implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private int column;

	private int line;

	//bi-directional many-to-one association to OrdersToTicket
	@OneToMany(mappedBy="ticket")
	private List<OrdersToTicket> ordersToTickets;

	public Ticket() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getColumn() {
		return this.column;
	}

	public void setColumn(int column) {
		this.column = column;
	}

	public int getLine() {
		return this.line;
	}

	public void setLine(int line) {
		this.line = line;
	}

	public List<OrdersToTicket> getOrdersToTickets() {
		return this.ordersToTickets;
	}

	public void setOrdersToTickets(List<OrdersToTicket> ordersToTickets) {
		this.ordersToTickets = ordersToTickets;
	}

	public OrdersToTicket addOrdersToTicket(OrdersToTicket ordersToTicket) {
		getOrdersToTickets().add(ordersToTicket);
		ordersToTicket.setTicket(this);

		return ordersToTicket;
	}

	public OrdersToTicket removeOrdersToTicket(OrdersToTicket ordersToTicket) {
		getOrdersToTickets().remove(ordersToTicket);
		ordersToTicket.setTicket(null);

		return ordersToTicket;
	}

}