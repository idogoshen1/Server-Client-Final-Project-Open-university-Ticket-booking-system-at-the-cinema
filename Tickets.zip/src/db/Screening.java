package db;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the screening database table.
 * 
 */
@Entity
@NamedQuery(name="Screening.findAll", query="SELECT s FROM Screening s")
public class Screening implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	@Temporal(TemporalType.TIMESTAMP)
	private Date dateAndTime;

	private float price;

	//bi-directional many-to-one association to Hall
	@ManyToOne
	@JoinColumn(name="HallID")
	private Hall hall;

	//bi-directional many-to-one association to Show
	@ManyToOne
	@JoinColumn(name="ShowID")
	private Show show;

	//bi-directional many-to-one association to TicketsOrder
	@OneToMany(mappedBy="screening")
	private List<TicketsOrder> ticketsOrders;

	public Screening() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getDateAndTime() {
		return this.dateAndTime;
	}

	public void setDateAndTime(Date dateAndTime) {
		this.dateAndTime = dateAndTime;
	}

	public float getPrice() {
		return this.price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Hall getHall() {
		return this.hall;
	}

	public void setHall(Hall hall) {
		this.hall = hall;
	}

	public Show getShow() {
		return this.show;
	}

	public void setShow(Show show) {
		this.show = show;
	}

	public List<TicketsOrder> getTicketsOrders() {
		return this.ticketsOrders;
	}

	public void setTicketsOrders(List<TicketsOrder> ticketsOrders) {
		this.ticketsOrders = ticketsOrders;
	}

	public TicketsOrder addTicketsOrder(TicketsOrder ticketsOrder) {
		getTicketsOrders().add(ticketsOrder);
		ticketsOrder.setScreening(this);

		return ticketsOrder;
	}

	public TicketsOrder removeTicketsOrder(TicketsOrder ticketsOrder) {
		getTicketsOrders().remove(ticketsOrder);
		ticketsOrder.setScreening(null);

		return ticketsOrder;
	}

	@Override
	public String toString() {
		return show.getName() + " on: " + dateAndTime;
	}

	
}