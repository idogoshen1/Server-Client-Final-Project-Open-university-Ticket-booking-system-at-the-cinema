package db;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the orders_to_tickets database table.
 * 
 */
@Entity
@Table(name="orders_to_tickets")
@NamedQuery(name="OrdersToTicket.findAll", query="SELECT o FROM OrdersToTicket o")
public class OrdersToTicket implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	//bi-directional many-to-one association to Ticket
	@ManyToOne
	@JoinColumn(name="TicketID")
	private Ticket ticket;

	//bi-directional many-to-one association to TicketsOrder
	@ManyToOne
	@JoinColumn(name="OrderID")
	private TicketsOrder ticketsOrder;

	public OrdersToTicket() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Ticket getTicket() {
		return this.ticket;
	}

	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}

	public TicketsOrder getTicketsOrder() {
		return this.ticketsOrder;
	}

	public void setTicketsOrder(TicketsOrder ticketsOrder) {
		this.ticketsOrder = ticketsOrder;
	}

}