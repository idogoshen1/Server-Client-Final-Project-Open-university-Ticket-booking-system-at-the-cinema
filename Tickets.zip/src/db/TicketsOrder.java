package db;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the tickets_orders database table.
 * 
 */
@Entity
@Table(name="tickets_orders")
@NamedQuery(name="TicketsOrder.findAll", query="SELECT t FROM TicketsOrder t")
public class TicketsOrder implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Temporal(TemporalType.TIMESTAMP)
	private Date orderDate;

	private byte paid;

	//bi-directional many-to-one association to OrdersToTicket
	@OneToMany(mappedBy="ticketsOrder", fetch = FetchType.EAGER)
	private List<OrdersToTicket> ordersToTickets;

	//bi-directional many-to-one association to Screening
	@ManyToOne
	@JoinColumn(name="ScreeningID")
	private Screening screening;

	//bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name="UserID")
	private User user;

	public TicketsOrder() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getOrderDate() {
		return this.orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public byte getPaid() {
		return this.paid;
	}

	public void setPaid(byte paid) {
		this.paid = paid;
	}

	public List<OrdersToTicket> getOrdersToTickets() {
		return this.ordersToTickets;
	}

	public void setOrdersToTickets(List<OrdersToTicket> ordersToTickets) {
		this.ordersToTickets = ordersToTickets;
	}

	public OrdersToTicket addOrdersToTicket(OrdersToTicket ordersToTicket) {
		getOrdersToTickets().add(ordersToTicket);
		ordersToTicket.setTicketsOrder(this);

		return ordersToTicket;
	}

	public OrdersToTicket removeOrdersToTicket(OrdersToTicket ordersToTicket) {
		getOrdersToTickets().remove(ordersToTicket);
		ordersToTicket.setTicketsOrder(null);

		return ordersToTicket;
	}

	public Screening getScreening() {
		return this.screening;
	}

	public void setScreening(Screening screening) {
		this.screening = screening;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}