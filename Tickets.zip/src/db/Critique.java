package db;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the critiques database table.
 * 
 */
@Entity
@Table(name="critiques")
@NamedQuery(name="Critique.findAll", query="SELECT c FROM Critique c")
public class Critique implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	private int critiqueRank;

	private String critiqueText;

	//bi-directional many-to-one association to Show
	@ManyToOne
	@JoinColumn(name="ShowID")
	private Show show;

	//bi-directional many-to-one association to User
	@ManyToOne
	@JoinColumn(name="UserID")
	private User user;

	public Critique() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCritiqueRank() {
		return this.critiqueRank;
	}

	public void setCritiqueRank(int critiqueRank) {
		this.critiqueRank = critiqueRank;
	}

	public String getCritiqueText() {
		return this.critiqueText;
	}

	public void setCritiqueText(String critiqueText) {
		this.critiqueText = critiqueText;
	}

	public Show getShow() {
		return this.show;
	}

	public void setShow(Show show) {
		this.show = show;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}