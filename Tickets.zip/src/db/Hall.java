package db;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the halls database table.
 * 
 */
@Entity
@Table(name="halls")
@NamedQuery(name="Hall.findAll", query="SELECT h FROM Hall h")
public class Hall implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	private int columns;

	private int houseNumber;

	private int lines;

	private String name;

	private String phone;

	//bi-directional many-to-one association to Street
	@ManyToOne
	@JoinColumn(name="StreetID")
	private Street street;

	//bi-directional many-to-one association to Screening
	@OneToMany(mappedBy="hall", fetch = FetchType.EAGER)
	private List<Screening> screenings;

	public Hall() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getColumns() {
		return this.columns;
	}

	public void setColumns(int columns) {
		this.columns = columns;
	}

	public int getHouseNumber() {
		return this.houseNumber;
	}

	public void setHouseNumber(int houseNumber) {
		this.houseNumber = houseNumber;
	}

	public int getLines() {
		return this.lines;
	}

	public void setLines(int lines) {
		this.lines = lines;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Street getStreet() {
		return this.street;
	}

	public void setStreet(Street street) {
		this.street = street;
	}

	public List<Screening> getScreenings() {
		return this.screenings;
	}

	public void setScreenings(List<Screening> screenings) {
		this.screenings = screenings;
	}

	public Screening addScreening(Screening screening) {
		getScreenings().add(screening);
		screening.setHall(this);

		return screening;
	}

	public Screening removeScreening(Screening screening) {
		getScreenings().remove(screening);
		screening.setHall(null);

		return screening;
	}

	@Override
	public String toString() {
		return "Hall: " + name;
	}
}