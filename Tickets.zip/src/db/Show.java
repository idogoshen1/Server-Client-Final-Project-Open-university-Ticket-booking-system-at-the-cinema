package db;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the shows database table.
 * 
 */
@Entity
@Table(name="shows")
@NamedQuery(name="Show.findAll", query="SELECT s FROM Show s")
public class Show implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	private String description;

	@Lob
	private byte[] image;

	private String name;

	//bi-directional many-to-one association to Critique
	@OneToMany(mappedBy="show")
	private List<Critique> critiques;

	//bi-directional many-to-one association to Screening
	@OneToMany(mappedBy="show", fetch = FetchType.EAGER)
	private List<Screening> screenings;

	public Show() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public byte[] getImage() {
		return this.image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Critique> getCritiques() {
		return this.critiques;
	}

	public void setCritiques(List<Critique> critiques) {
		this.critiques = critiques;
	}

	public Critique addCritique(Critique critique) {
		getCritiques().add(critique);
		critique.setShow(this);

		return critique;
	}

	public Critique removeCritique(Critique critique) {
		getCritiques().remove(critique);
		critique.setShow(null);

		return critique;
	}

	public List<Screening> getScreenings() {
		return this.screenings;
	}

	public void setScreenings(List<Screening> screenings) {
		this.screenings = screenings;
	}

	public Screening addScreening(Screening screening) {
		getScreenings().add(screening);
		screening.setShow(this);

		return screening;
	}

	public Screening removeScreening(Screening screening) {
		getScreenings().remove(screening);
		screening.setShow(null);

		return screening;
	}

	@Override
	public String toString() {
		return "Show (" + id + ") " + name;
	}
}