package db;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the streets database table.
 * 
 */
@Entity
@Table(name="streets")
@NamedQuery(name="Street.findAll", query="SELECT s FROM Street s")
public class Street implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	private String name;

	//bi-directional many-to-one association to Hall
	@OneToMany(mappedBy="street")
	private List<Hall> halls;

	//bi-directional many-to-one association to City
	@ManyToOne
	@JoinColumn(name="CityID")
	private City city;

	public Street() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Hall> getHalls() {
		return this.halls;
	}

	public void setHalls(List<Hall> halls) {
		this.halls = halls;
	}

	public Hall addHall(Hall hall) {
		getHalls().add(hall);
		hall.setStreet(this);

		return hall;
	}

	public Hall removeHall(Hall hall) {
		getHalls().remove(hall);
		hall.setStreet(null);

		return hall;
	}

	public City getCity() {
		return this.city;
	}

	public void setCity(City city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return name;
	}
}