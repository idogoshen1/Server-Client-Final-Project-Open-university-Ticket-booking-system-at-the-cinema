package db;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the cities database table.
 * 
 */
@Entity
@Table(name="cities")
@NamedQuery(name="City.findAll", query="SELECT c FROM City c")
public class City implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	private String name;

	//bi-directional many-to-one association to Street
	@OneToMany(mappedBy="city", fetch = FetchType.EAGER)
	private List<Street> streets;

	public City() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Street> getStreets() {
		return this.streets;
	}

	public void setStreets(List<Street> streets) {
		this.streets = streets;
	}

	public Street addStreet(Street street) {
		getStreets().add(street);
		street.setCity(this);

		return street;
	}

	public Street removeStreet(Street street) {
		getStreets().remove(street);
		street.setCity(null);

		return street;
	}

	@Override
	public String toString() {
		return name + " (" + id + ")";
	}

}