package common;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import db.City;
import db.Critique;
import db.Hall;
import db.Screening;
import db.Show;
import db.Ticket;
import db.TicketsOrder;
import db.User;

/**
 * RMI interface that represents the server for the communication between the client
 * and the server
 * @author Ido Goshen
 *
 */
public interface ServerManager extends Remote {
	/**
	 * @param userName the user name
	 * @param password the password
	 * @return the user
	 * @throws RemoteException
	 */
	public User getUser(String userName, String password) throws RemoteException;

	/**
	 * sign up a new user
	 * @param firstName the first name
	 * @param lastName the last name
	 * @param mail the mail
	 * @param userName the user name
	 * @param password the password
	 * @param phone the phone
	 * @return a new user
	 * @throws RemoteException
	 */
	public User signUp(String firstName, String lastName, String mail,
			String userName, String password, String phone) throws RemoteException;

	/**
	 * @return all users
	 * @throws RemoteException
	 */
	public List<User> getAllUsers() throws RemoteException;

	/**
	 * delete a user
	 * @param user the user
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean delete(User user) throws RemoteException;

	/**
	 * update a user
	 * @param user the user
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean update(User user) throws RemoteException;

	/**
	 * create a new user
	 * @param user the user
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean create(User user) throws RemoteException;

	/**
	 * @return all halls
	 * @throws RemoteException
	 */
	public List<Hall> getAllHalls() throws RemoteException;

	/**
	 * @return all cities
	 * @throws RemoteException
	 */
	public List<City> getAllCities() throws RemoteException;

	/**
	 * create a new hall
	 * @param hall the hall
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean create(Hall hall) throws RemoteException;

	/**
	 * delete a hall
	 * @param hall the hall
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean delete(Hall hall) throws RemoteException;

	/**
	 * update a hall
	 * @param hall the hall
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean update(Hall hall) throws RemoteException;

	/**
	 * @return all shows
	 * @throws RemoteException
	 */
	public List<Show> getAllShows() throws RemoteException;

	/**
	 * create a new show
	 * @param show the show
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean create(Show show) throws RemoteException;

	/**
	 * update a show
	 * @param show the show
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean update(Show show) throws RemoteException;

	/**
	 * delete a show
	 * @param show the show
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean delete(Show show) throws RemoteException;

	/**
	 * @param show the show
	 * @return the screenings of a specific show
	 * @throws RemoteException
	 */
	public List<Screening> getScreenings(Show show) throws RemoteException;

	/**
	 * create a new screening
	 * @param screening the screening
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean create(Screening screening) throws RemoteException;

	/**
	 * delete a screening
	 * @param screening the screening
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean delete(Screening screening) throws RemoteException;

	/**
	 * update a screening
	 * @param screening the screening
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean update(Screening screening) throws RemoteException;

	/**
	 * @param screening the screening
	 * @param user the user
	 * @return the orders of a screening of a specific user
	 * @throws RemoteException
	 */
	public List<TicketsOrder> getOrders(Screening screening, User user) throws RemoteException;

	/**
	 * place a new order
	 * @param screeningID the screening ID
	 * @param userID the user ID
	 * @param tickets the tickets for the new order
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean placeOrder(int screeningID, int userID, ArrayList<Ticket> tickets) throws RemoteException;

	/**
	 * @param userID the user ID
	 * @return the orders of a specific user
	 * @throws RemoteException
	 */
	public List<TicketsOrder> getOrders(int userID) throws RemoteException;

	/**
	 * pay an order
	 * @param orderID the order ID
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean pay(int orderID) throws RemoteException;

	/**
	 * delete an order
	 * @param order the order
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean delete(TicketsOrder order) throws RemoteException;

	/**
	 * check if the server is alive
	 * @throws RemoteException
	 */
	public void ping() throws RemoteException;

	/**
	 * create a new critique
	 * @param critique the critique to be created
	 * @return true on success
	 * @throws Exception
	 */
	public boolean create(Critique critique) throws RemoteException;

	/**
	 * @param show the show
	 * @return the critiques of a specific show
	 */
	public List<Critique> getCritiques(Show show) throws RemoteException;
}
