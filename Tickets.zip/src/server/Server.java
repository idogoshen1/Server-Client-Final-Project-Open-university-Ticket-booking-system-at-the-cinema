package server;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

/**
 * the class that runs the server
 * @author Ido Goshen
 *
 */
public class Server {
	public static void main(String[] args) {
		System.out.println("RMI server started");
		try { //special exception handler for registry creation
            LocateRegistry.createRegistry(1099);
            System.out.println("java RMI registry created.");
            //Instantiate ServerManagerImplementation
    		ServerManagerImplementation server = new ServerManagerImplementation();

            // Bind this object instance to the name "RmiServer"
            Naming.rebind("//localhost/ServerManager", server);
            System.out.println("PeerServer bound in registry");
        } catch (RemoteException e) {
            //do nothing, error means registry already exists
            System.out.println("java RMI registry already exists.");
        } catch (Exception e) {
			e.printStackTrace();
		}
	}

}
