package server;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import db.City;
import db.Critique;
import db.Hall;
import db.OrdersToTicket;
import db.Screening;
import db.Show;
import db.Street;
import db.Ticket;
import db.TicketsOrder;
import db.User;

/**
 * handle the all DB issues using JPA.
 * this class is a singleton.
 * @author Ido Goshen
 *
 */
public class DataBaseManager {
	/**
	 * the factory
	 */
	private EntityManagerFactory emfactory;
	/**
	 * the entity manager
	 */
	private EntityManager em;
	/**
	 * reference to the singleton object
	 */
	static private DataBaseManager manager;

	/**
	 * the constructor is private so no one will be able to create
	 * instances of this class
	 */
	private DataBaseManager() {
		try {
			// load the DB and JPA related classes
			Class.forName("com.mysql.cj.jdbc.Driver");
            Class.forName("org.hibernate.jpa.HibernatePersistenceProvider");
            System.out.println("Found DB related classes");
        } catch (Exception e){
            e.printStackTrace();
        }
		emfactory = Persistence.createEntityManagerFactory("tickets");
		em = emfactory.createEntityManager();
		manager = this;
	}
	/**
	 * @param userName the user name
	 * @param password the password
	 * @return the user
	 * @throws RemoteException
	 */
	public User getUser(String userName, String password) throws RemoteException {
		TypedQuery<User> query = em.createQuery("SELECT c FROM User As c WHERE c.userName = :userName and c.password = :password", User.class);
		query.setParameter("userName", userName);
		query.setParameter("password", password);
		List<User> results = query.getResultList();
		if (results.size() != 1)
			return null;
		return results.get(0);
	}
	/**
	 * return a user by ID
	 * @param ID the user ID
	 * @return the user
	 * @throws RemoteException
	 */
	public User getUser(int ID) throws RemoteException {
		TypedQuery<User> query = em.createQuery("SELECT c FROM User As c WHERE c.id = :id", User.class);
		query.setParameter("id", ID);
		List<User> results = query.getResultList();
		if (results.size() != 1)
			return null;
		return results.get(0);
	}
	/**
	 * return a user by user name
	 * @param userName the user name
	 * @return the user
	 * @throws RemoteException
	 */
	public User getUser(String userName) {
		TypedQuery<User> query = em.createQuery("SELECT c FROM User As c WHERE c.userName = :userName", User.class);
		query.setParameter("userName", userName);
		List<User> results = query.getResultList();
		if (results.size() != 1)
			return null;
		return results.get(0);
	}
	/**
	 * sign up a new user
	 * @param firstName the first name
	 * @param lastName the last name
	 * @param mail the mail
	 * @param userName the user name
	 * @param password the password
	 * @param phone the phone
	 * @return a new user
	 * @throws RemoteException
	 */
	public User signUp(String firstName, String lastName, String mail,
			String userName, String password, String phone) throws RemoteException {
		User existingUser = getUser(userName);
		if (existingUser != null) {
			throw new RemoteException("User already exist");
		}
		// create a new user (not a manager)
		byte manager = 0;
		em = emfactory.createEntityManager();
		User user = new User();
		user.setFirstName(firstName);
		user.setLastName(lastName);
		user.setMail(mail);
		user.setUserName(userName);
		user.setPassword(password);
		user.setPhone(phone);
		user.setManager(manager);
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(user);
		em.flush();
		et.commit();
		return getUser(user.getId());
	}
	/**
	 * create the DB manager if it wasn't created yet and return it
	 * @return the DB manager
	 */
	public static DataBaseManager getManager() {
		if (manager == null)
			manager = new DataBaseManager();
		return manager;
	}
	/**
	 * @return all users
	 * @throws RemoteException
	 */
	public List<User> getAllUsers() {
		TypedQuery<User> query = em.createQuery("SELECT c FROM User As c", User.class);
		List<User> results = query.getResultList();
		return results;
	}
	/**
	 * delete a user
	 * @param user the user
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean delete(User user) {
		try {
			em = emfactory.createEntityManager();
			User deletedUser = getUser(user.getId());
			if (deletedUser == null)
				return false;
			em.getTransaction().begin();
			em.remove(deletedUser);
			em.getTransaction().commit();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	/**
	 * update a user
	 * @param user the user
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean update(User user) throws RemoteException {
		User existingUser = getUser(user.getUserName());
		if ((existingUser != null) && (existingUser.getId() != user.getId())) {
			throw new RemoteException("User already exist");
		}
		em = emfactory.createEntityManager();
		User updatedUser = getUser(user.getId());
		if (updatedUser == null)
			return false;
		em.getTransaction().begin();
		updatedUser.setFirstName(user.getFirstName());
		updatedUser.setLastName(user.getLastName());
		updatedUser.setMail(user.getMail());
		updatedUser.setPassword(user.getPassword());
		updatedUser.setPhone(user.getPhone());
		updatedUser.setUserName(user.getUserName());
		updatedUser.setManager(user.getManager());
		em.merge(updatedUser);
		em.getTransaction().commit();
		return true;
	}
	/**
	 * create a new user
	 * @param user the user
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean create(User user) throws RemoteException {
		User existingUser = getUser(user.getUserName());
		if (existingUser != null) {
			throw new RemoteException("User already exist");
		}
		em = emfactory.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(user);
		em.flush();
		et.commit();
		return true;
	}
	/**
	 * @return all halls
	 * @throws RemoteException
	 */
	public List<Hall> getAllHalls() {
		TypedQuery<Hall> query = em.createQuery("SELECT c FROM Hall As c", Hall.class);
		List<Hall> results = query.getResultList();
		return results;
	}
	/**
	 * @return all cities
	 * @throws RemoteException
	 */
	public List<City> getAllCities() {
		TypedQuery<City> query = em.createQuery("SELECT c FROM City As c", City.class);
		List<City> results = query.getResultList();
		return results;
	}
	/**
	 * return a street by ID
	 * @param id the street ID
	 * @return the street
	 */
	private Street getStreet(int id) {
		TypedQuery<Street> query = em.createQuery("SELECT c FROM Street As c WHERE c.id = :id", Street.class);
		query.setParameter("id", id);
		List<Street> results = query.getResultList();
		if (results.size() != 1)
			return null;
		return results.get(0);
	}
	/**
	 * create a new hall
	 * @param hall the hall
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean create(Hall hall) {
		try {
			em = emfactory.createEntityManager();
			hall.setStreet(getStreet(hall.getStreet().getId()));
			EntityTransaction et = em.getTransaction();
			et.begin();
			em.persist(hall);
			em.flush();
			et.commit();
			return true;
		}
		catch (Exception e) {
			return false;
		}
	}
	/**
	 * return a hall by ID
	 * @param ID the hall ID
	 * @return the hall
	 */
	private Hall getHall(int ID) throws RemoteException {
		TypedQuery<Hall> query = em.createQuery("SELECT c FROM Hall As c WHERE c.id = :id", Hall.class);
		query.setParameter("id", ID);
		List<Hall> results = query.getResultList();
		if (results.size() != 1)
			return null;
		return results.get(0);
	}
	/**
	 * delete a hall
	 * @param hall the hall
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean delete(Hall hall) {
		try {
			em = emfactory.createEntityManager();
			Hall deletedHall = getHall(hall.getId());
			if (deletedHall == null)
				return false;
			em.getTransaction().begin();
			em.remove(deletedHall);
			em.getTransaction().commit();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	/**
	 * update a hall
	 * @param hall the hall
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean update(Hall hall) {
		try {
			em = emfactory.createEntityManager();
			Hall updatedHall = getHall(hall.getId());
			if (updatedHall == null)
				return false;
			em.getTransaction().begin();
			updatedHall.setColumns(hall.getColumns());
			updatedHall.setHouseNumber(hall.getHouseNumber());
			updatedHall.setLines(hall.getLines());
			updatedHall.setName(hall.getName());
			updatedHall.setPhone(hall.getPhone());
			updatedHall.setStreet(getStreet(hall.getStreet().getId()));
			em.merge(updatedHall);
			em.getTransaction().commit();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	/**
	 * @return all shows
	 * @throws RemoteException
	 */
	public List<Show> getAllShows() {
		TypedQuery<Show> query = em.createQuery("SELECT c FROM Show As c", Show.class);
		List<Show> results = query.getResultList();
		return results;
	}
	/**
	 * create a new show
	 * @param show the show
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean create(Show show) {
		try {
			em = emfactory.createEntityManager();
			EntityTransaction et = em.getTransaction();
			et.begin();
			em.persist(show);
			em.flush();
			et.commit();
			return true;
		}
		catch (Exception e) {
			return false;
		}
	}
	/**
	 * update a show
	 * @param show the show
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean update(Show show) {
		try {
			em = emfactory.createEntityManager();
			Show updatedShow = getShow(show.getId());
			if (updatedShow == null)
				return false;
			em.getTransaction().begin();
			updatedShow.setDescription(show.getDescription());
			updatedShow.setImage(show.getImage());
			updatedShow.setName(show.getName());
			em.merge(updatedShow);
			em.getTransaction().commit();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	/**
	 * return a show by ID
	 * @param ID the show ID
	 * @return the show
	 */
	private Show getShow(int ID) throws RemoteException {
		TypedQuery<Show> query = em.createQuery("SELECT c FROM Show As c WHERE c.id = :id", Show.class);
		query.setParameter("id", ID);
		List<Show> results = query.getResultList();
		if (results.size() != 1)
			return null;
		return results.get(0);
	}
	/**
	 * delete a show
	 * @param show the show
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean delete(Show show) {
		try {
			em = emfactory.createEntityManager();
			Show deletedShow = getShow(show.getId());
			if (deletedShow == null)
				return false;
			em.getTransaction().begin();
			em.remove(deletedShow);
			em.getTransaction().commit();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	/**
	 * @param show the show
	 * @return the screenings of a specific show
	 * @throws RemoteException
	 */
	public List<Screening> getScreenings(Show show) {
		Date now = new Date();
		TypedQuery<Screening> query = em.createQuery("SELECT c FROM Screening As c WHERE c.show.id = :id and c.dateAndTime >= :date", Screening.class);
		query.setParameter("id", show.getId());
		query.setParameter("date", now);
		List<Screening> results = query.getResultList();
		return results;
	}
	/**
	 * create a new screening
	 * @param screening the screening
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean create(Screening screening) {
		try {
			Show show = getShow(screening.getShow().getId());
			screening.setShow(show);
			Hall hall = getHall(screening.getHall().getId());
			screening.setHall(hall);
			em = emfactory.createEntityManager();
			EntityTransaction et = em.getTransaction();
			et.begin();
			em.persist(screening);
			em.flush();
			et.commit();
			return true;
		}
		catch (Exception e) {
			return false;
		}
	}
	/**
	 * delete a screening
	 * @param screening the screening
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean delete(Screening screening) {
		try {
			em = emfactory.createEntityManager();
			Screening deletedScreening = getScreening(screening.getId());
			if (deletedScreening == null)
				return false;
			em.getTransaction().begin();
			em.remove(deletedScreening);
			em.getTransaction().commit();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	/**
	 * return a screening by ID
	 * @param ID the screening ID
	 * @return the screening
	 */
	private Screening getScreening(int ID) {
		TypedQuery<Screening> query = em.createQuery("SELECT c FROM Screening As c WHERE c.id = :id", Screening.class);
		query.setParameter("id", ID);
		List<Screening> results = query.getResultList();
		if (results.size() != 1)
			return null;
		return results.get(0);
	}
	/**
	 * update a screening
	 * @param screening the screening
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean update(Screening screening) {
		try {
			em = emfactory.createEntityManager();
			Screening updatedScreening = getScreening(screening.getId());
			if (updatedScreening == null)
				return false;
			em.getTransaction().begin();
			updatedScreening.setDateAndTime(screening.getDateAndTime());
			updatedScreening.setHall(getHall(screening.getHall().getId()));
			updatedScreening.setShow(getShow(screening.getShow().getId()));
			em.merge(updatedScreening);
			em.getTransaction().commit();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	/**
	 * @param screening the screening
	 * @param user the user
	 * @return the orders of a screening of a specific user
	 * @throws RemoteException
	 */
	public List<TicketsOrder> getOrders(Screening screening, User user) {
		TypedQuery<TicketsOrder> query = em.createQuery("SELECT c FROM TicketsOrder As c WHERE c.screening.id = :screeningid and c.user.id = :userid", TicketsOrder.class);
		query.setParameter("screeningid", screening.getId());
		query.setParameter("userid", user.getId());
		List<TicketsOrder> results = query.getResultList();
		return results;
	}
	/**
	 * return a ticket by ID
	 * @param ID the ticket ID
	 * @return the ticket
	 */
	private Ticket getTicket(int ID) {
		TypedQuery<Ticket> query = em.createQuery("SELECT c FROM Ticket As c WHERE c.id = :id", Ticket.class);
		query.setParameter("id", ID);
		List<Ticket> results = query.getResultList();
		if (results.size() != 1)
			return null;
		return results.get(0);
	}
	/**
	 * return an order to ticket by ID
	 * @param ID the order to ticket ID
	 * @return the order to ticket
	 */
	private OrdersToTicket getOrdersToTicket(int ID) {
		TypedQuery<OrdersToTicket> query = em.createQuery("SELECT c FROM OrdersToTicket As c WHERE c.id = :id", OrdersToTicket.class);
		query.setParameter("id", ID);
		List<OrdersToTicket> results = query.getResultList();
		if (results.size() != 1)
			return null;
		return results.get(0);
	}
	/**
	 * return an order by ID
	 * @param ID the order ID
	 * @return the order
	 */
	private TicketsOrder getOrder(int ID) {
		TypedQuery<TicketsOrder> query = em.createQuery("SELECT c FROM TicketsOrder As c WHERE c.id = :id", TicketsOrder.class);
		query.setParameter("id", ID);
		List<TicketsOrder> results = query.getResultList();
		if (results.size() != 1)
			return null;
		return results.get(0);
	}
	/**
	 * place a new order
	 * @param screeningID the screening ID
	 * @param userID the user ID
	 * @param tickets the tickets for the new order
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean placeOrder(int screeningID, int userID, ArrayList<Ticket> tickets) {
		try {
			Screening screening = getScreening(screeningID);
			User user = getUser(userID);
			TicketsOrder order = new TicketsOrder();
			order.setOrderDate(new Date());
			order.setScreening(screening);
			order.setUser(user);
			em = emfactory.createEntityManager();
			EntityTransaction et = em.getTransaction();
			et.begin();
			em.persist(order);
			em.flush();
			et.commit();
			order = getOrder(order.getId());
			List<OrdersToTicket> ordersToTickets = new ArrayList<OrdersToTicket>();
			OrdersToTicket ott;
			for (Ticket ticket : tickets) {

				em = emfactory.createEntityManager();
				et = em.getTransaction();
				et.begin();
				em.persist(ticket);
				em.flush();
				et.commit();
				ticket = getTicket(ticket.getId());

				ott = new OrdersToTicket();
				ott.setTicket(ticket);
				ott.setTicketsOrder(order);
				em = emfactory.createEntityManager();
				et = em.getTransaction();
				et.begin();
				em.persist(ott);
				em.flush();
				et.commit();

				ott = getOrdersToTicket(ott.getId());
				ordersToTickets.add(ott);
			}

			order.setOrdersToTickets(ordersToTickets);
			em = emfactory.createEntityManager();
			et = em.getTransaction();
			et.begin();
			em.merge(order);
			em.flush();
			et.commit();
			return true;
		}
		catch (Exception e) {
			return false;
		}
	}
	/**
	 * @param userID the user ID
	 * @return the orders of a specific user
	 * @throws RemoteException
	 */
	public List<TicketsOrder> getOrders(int userID) {
		TypedQuery<TicketsOrder> query = em.createQuery("SELECT c FROM TicketsOrder As c WHERE c.user.id = :userid", TicketsOrder.class);
		try {
			// manager shows all orders
			User user = getUser(userID);
			if ((user != null) && (user.getManager() == 1)) {
				query = em.createQuery("SELECT c FROM TicketsOrder As c", TicketsOrder.class);
			}
			else {
				query.setParameter("userid", userID);
			}
		}
		catch (Exception e) {
		}
		List<TicketsOrder> results = query.getResultList();
		return results;
	}
	/**
	 * pay an order
	 * @param orderID the order ID
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean pay(int orderID) {
		try {
			em = emfactory.createEntityManager();
			TicketsOrder updatedOrder = getOrder(orderID);
			if (updatedOrder == null)
				return false;
			em.getTransaction().begin();
			updatedOrder.setPaid((byte) 1);
			em.merge(updatedOrder);
			em.getTransaction().commit();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	/**
	 * delete an order
	 * @param order the order
	 * @return true on success
	 * @throws RemoteException
	 */
	public boolean delete(TicketsOrder order) {
		try {
			em = emfactory.createEntityManager();
			TicketsOrder deletedOrder = getOrder(order.getId());
			if (deletedOrder == null)
				return false;
			em.getTransaction().begin();
			List<OrdersToTicket> ordersToTickets = deletedOrder.getOrdersToTickets();
			for (OrdersToTicket ott : ordersToTickets) {
				Ticket ticket = ott.getTicket();
				em.remove(ticket);
				em.remove(ott);
			}
			em.remove(deletedOrder);
			em.getTransaction().commit();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * create a new critique
	 * @param critique the critique to be created
	 * @return true on success
	 */
	public boolean create(Critique critique) {
		try {
			User existingUser = getUser(critique.getUser().getId());
			if (existingUser == null) {
				throw new RemoteException("User not exist");
			}
			Show existingShow = getShow(critique.getShow().getId());
			if (existingShow == null) {
				throw new RemoteException("Show not exist");
			}
			critique.setUser(existingUser);
			critique.setShow(existingShow);
			em = emfactory.createEntityManager();
			EntityTransaction et = em.getTransaction();
			et.begin();
			em.persist(critique);
			em.flush();
			et.commit();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	/**
	 * @param show the show
	 * @return the critiques of a specific show
	 */
	public List<Critique> getCritiques(Show show) {
		try {
			TypedQuery<Critique> query = em.createQuery("SELECT c FROM Critique As c WHERE c.show.id = :id", Critique.class);
			query.setParameter("id", show.getId());
			List<Critique> results = query.getResultList();
			return results;
		} catch (Exception e) {
			return null;
		}
	}
}
