package server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

import common.ServerManager;
import db.City;
import db.Critique;
import db.Hall;
import db.Screening;
import db.Show;
import db.Ticket;
import db.TicketsOrder;
import db.User;

/**
 * implementation of the server for the communication between the client
 * and the server
 * @author Ido Goshen
 *
 */
public class ServerManagerImplementation extends UnicastRemoteObject implements ServerManager {

	protected ServerManagerImplementation() throws RemoteException {
	}

	/**
	 * @param userName the user name
	 * @param password the password
	 * @return the user
	 * @throws RemoteException
	 */
	@Override
	public User getUser(String userName, String password) throws RemoteException {
		return DataBaseManager.getManager().getUser(userName, password);
	}
	/**
	 * sign up a new user
	 * @param firstName the first name
	 * @param lastName the last name
	 * @param mail the mail
	 * @param userName the user name
	 * @param password the password
	 * @param phone the phone
	 * @return a new user
	 * @throws RemoteException
	 */
	public User signUp(String firstName, String lastName, String mail,
			String userName, String password, String phone) throws RemoteException {
		return DataBaseManager.getManager().signUp(firstName, lastName, mail, userName, password, phone);
	}

	/**
	 * @return all users
	 * @throws RemoteException
	 */
	public List<User> getAllUsers() throws RemoteException {
		return DataBaseManager.getManager().getAllUsers();
	}

	/**
	 * delete a user
	 * @param user the user
	 * @return true on success
	 * @throws RemoteException
	 */
	@Override
	public boolean delete(User user) throws RemoteException {
		return DataBaseManager.getManager().delete(user);
	}

	/**
	 * update a user
	 * @param user the user
	 * @return true on success
	 * @throws RemoteException
	 */
	@Override
	public boolean update(User user) throws RemoteException {
		return DataBaseManager.getManager().update(user);
	}

	/**
	 * create a new user
	 * @param user the user
	 * @return true on success
	 * @throws RemoteException
	 */
	@Override
	public boolean create(User user) throws RemoteException {
		return DataBaseManager.getManager().create(user);
	}

	/**
	 * @return all halls
	 * @throws RemoteException
	 */
	@Override
	public List<Hall> getAllHalls() throws RemoteException {
		return DataBaseManager.getManager().getAllHalls();
	}

	/**
	 * @return all cities
	 * @throws RemoteException
	 */
	@Override
	public List<City> getAllCities() throws RemoteException {
		return DataBaseManager.getManager().getAllCities();
	}

	/**
	 * create a new hall
	 * @param hall the hall
	 * @return true on success
	 * @throws RemoteException
	 */
	@Override
	public boolean create(Hall hall) throws RemoteException {
		return DataBaseManager.getManager().create(hall);
	}

	/**
	 * delete a hall
	 * @param hall the hall
	 * @return true on success
	 * @throws RemoteException
	 */
	@Override
	public boolean delete(Hall hall) throws RemoteException {
		return DataBaseManager.getManager().delete(hall);
	}

	/**
	 * update a hall
	 * @param hall the hall
	 * @return true on success
	 * @throws RemoteException
	 */
	@Override
	public boolean update(Hall hall) throws RemoteException {
		return DataBaseManager.getManager().update(hall);
	}

	/**
	 * @return all shows
	 * @throws RemoteException
	 */
	@Override
	public List<Show> getAllShows() throws RemoteException {
		return DataBaseManager.getManager().getAllShows();
	}

	/**
	 * create a new show
	 * @param show the show
	 * @return true on success
	 * @throws RemoteException
	 */
	@Override
	public boolean create(Show show) throws RemoteException {
		return DataBaseManager.getManager().create(show);
	}

	/**
	 * update a show
	 * @param show the show
	 * @return true on success
	 * @throws RemoteException
	 */
	@Override
	public boolean update(Show show) throws RemoteException {
		return DataBaseManager.getManager().update(show);
	}

	/**
	 * delete a show
	 * @param show the show
	 * @return true on success
	 * @throws RemoteException
	 */
	@Override
	public boolean delete(Show show) throws RemoteException {
		return DataBaseManager.getManager().delete(show);
	}

	/**
	 * @param show the show
	 * @return the screenings of a specific show
	 * @throws RemoteException
	 */
	@Override
	public List<Screening> getScreenings(Show show) throws RemoteException {
		return DataBaseManager.getManager().getScreenings(show);
	}

	/**
	 * create a new screening
	 * @param screening the screening
	 * @return true on success
	 * @throws RemoteException
	 */
	@Override
	public boolean create(Screening screening) throws RemoteException {
		return DataBaseManager.getManager().create(screening);
	}

	/**
	 * delete a screening
	 * @param screening the screening
	 * @return true on success
	 * @throws RemoteException
	 */
	@Override
	public boolean delete(Screening screening) throws RemoteException {
		return DataBaseManager.getManager().delete(screening);
	}

	/**
	 * update a screening
	 * @param screening the screening
	 * @return true on success
	 * @throws RemoteException
	 */
	@Override
	public boolean update(Screening screening) throws RemoteException {
		return DataBaseManager.getManager().update(screening);
	}

	/**
	 * @param screening the screening
	 * @param user the user
	 * @return the orders of a screening of a specific user
	 * @throws RemoteException
	 */
	@Override
	public List<TicketsOrder> getOrders(Screening screening, User user) throws RemoteException {
		return DataBaseManager.getManager().getOrders(screening, user);
	}

	/**
	 * place a new order
	 * @param screeningID the screening ID
	 * @param userID the user ID
	 * @param tickets the tickets for the new order
	 * @return true on success
	 * @throws RemoteException
	 */
	@Override
	public boolean placeOrder(int screeningID, int userID, ArrayList<Ticket> tickets) throws RemoteException {
		return DataBaseManager.getManager().placeOrder(screeningID, userID, tickets);
	}

	/**
	 * @param userID the user ID
	 * @return the orders of a specific user
	 * @throws RemoteException
	 */
	@Override
	public List<TicketsOrder> getOrders(int userID) throws RemoteException {
		return DataBaseManager.getManager().getOrders(userID);
	}

	/**
	 * pay an order
	 * @param orderID the order ID
	 * @return true on success
	 * @throws RemoteException
	 */
	@Override
	public boolean pay(int orderID) throws RemoteException {
		return DataBaseManager.getManager().pay(orderID);
	}

	/**
	 * delete an order
	 * @param order the order
	 * @return true on success
	 * @throws RemoteException
	 */
	@Override
	public boolean delete(TicketsOrder order) throws RemoteException {
		return DataBaseManager.getManager().delete(order);
	}

	/**
	 * check if the server is alive
	 * @throws RemoteException
	 */
	@Override
	public void ping() throws RemoteException {
		// do nothing, just for test if the server is alive
	}

	/**
	 * create a new critique
	 * @param critique the critique to be created
	 * @return true on success
	 * @throws Exception
	 */
	@Override
	public boolean create(Critique critique) throws RemoteException {
		return DataBaseManager.getManager().create(critique);
	}

	/**
	 * @param show the show
	 * @return the critiques of a specific show
	 */
	@Override
	public List<Critique> getCritiques(Show show) throws RemoteException {
		return DataBaseManager.getManager().getCritiques(show);
	}
}
